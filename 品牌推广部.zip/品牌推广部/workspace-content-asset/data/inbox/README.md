# 内容资产生成 Agent inbox

放置人工录入、源系统摘要、上游 Agent 输出或验收样例输入。格式建议使用 JSONL，每行一条记录，必须包含 `source_ref`、`campaign_id` 和 `review_status`。

# HEARTBEAT.md - 内容资产生成 Agent

心跳只做轻量运行检查：

1. 检查 `data/outbox/*.jsonl` 是否有超过 3 个工作日的待审核 Campaign 输出。
2. 检查 `mvp1_agent_runs` 是否存在失败或超时运行。
3. 检查 `mvp1_reviews` 是否存在 R3/R4 且未给出人工结论的事项。
4. 检查 `data/inbox/*.jsonl` 是否有未归一化输入。

输出 `HEARTBEAT_OK` 或事项清单；不得生成新 Campaign，也不得发布内容。

# 渠道推广编排 Agent outbox

保存待审核输出、`session send` payload、`writeback_plan` 和发布包索引。这里的内容不代表已发布或已写入外部系统。

# TOOLS.md - 渠道推广编排 Agent

## 本地数据

- 读 GDP schema：`../../data/schema.sql`。
- 读 GDP 数据：`../../data/gdp.sqlite`。
- 读本域目录：`data/catalog.json`。
- 收输入：`data/inbox/*.jsonl`。
- 写待审核输出：`data/outbox/*.jsonl`。

## 协同

- 跨 Agent 任务统一使用 `session send`。
- 消息字段必须包含 `campaign_id`、`from_agent`、`to_agent`、`task_type`、`input_refs`、`expected_output`、`risk_level`、`review_required`、`writeback_plan`。
- 本 Agent 不直接读取其他工作区原始 inbox/outbox。

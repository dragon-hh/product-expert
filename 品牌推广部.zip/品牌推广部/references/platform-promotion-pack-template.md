# 平台发布包模板

| Platform | Content_ID | Title | Format | Publish_Window | CTA | UTM | Checklist |
| --- | --- | --- | --- | --- | --- | --- | --- |

发布包仅供人工审核和执行，不自动调用平台发布 API。

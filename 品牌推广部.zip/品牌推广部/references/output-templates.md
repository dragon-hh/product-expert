# 输出模板

## Markdown 摘要

- Campaign_ID：
- 主责 Agent：
- 输入目标：
- 区域/国家/平台：
- 产品线/型号/场景：
- 风险等级：
- 审核状态：
- 证据引用：
- 下一步：

## 结构化 JSON

```json
{
  "campaign_id": "CMP-YYYY-REGION-PRODUCT-NNN",
  "owner_agent": "",
  "risk_level": "R1|R2|R3|R4",
  "review_required": true,
  "source_refs": [],
  "outputs": {},
  "writeback_plan": [],
  "next_agent_message": null
}
```

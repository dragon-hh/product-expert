# ID 规则

| 对象 | 格式 |
| --- | --- |
| Campaign_ID | `CMP-YYYY-REGION-PRODUCT-NNN` |
| Content_ID | `CNT-YYYY-PLATFORM-ASSET-NNN` |
| Pack_ID | `PACK-YYYY-CAMPAIGN-NNN` |
| UTM_ID | `UTM-YYYY-CAMPAIGN-NNN` |
| Review_ID | `REV-YYYYMMDD-NNN` |
| Run_ID | `RUN-YYYYMMDDHHMMSS-AGENT-SKILL` |

缺少主键的输入不得自动写入 GDP，必须先输出补充字段请求。

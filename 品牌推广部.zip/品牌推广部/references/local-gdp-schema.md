# 本地 GDP Schema

    SQLite 文件：`data/gdp.sqlite`。

    | 表名 | 主键 | 用途 |
    | --- | --- | --- |
    | `mvp1_campaigns` | `campaign_id` | Campaign brief and planning status. |
| `mvp1_platform_channels` | `channel_id` | Approved platform channel library. |
| `mvp1_products` | `product_model` | Product facts, certifications, compatibility, and available regions. |
| `mvp1_feasibility_checks` | `check_id` | Inventory, supply, deliverability, customer-profile, and ROI feasibility checks. |
| `mvp1_customer_profiles` | `profile_id` | Customer profile and segmentation summaries without exporting customer details. |
| `mvp1_roi_estimates` | `roi_id` | Budget, margin, lead, RFQ, order, and ROI estimates. |
| `mvp1_content_requirements` | `requirement_id` | Content asset requirements by campaign, platform, language, scenario, and CTA. |
| `mvp1_content_assets` | `content_id` | Generated draft content assets with fact references and review status. |
| `mvp1_promotion_packs` | `pack_id` | Human-reviewable platform promotion packs. |
| `mvp1_utm_links` | `utm_id` | UTM, Content_ID, Campaign_ID mapping. |
| `mvp1_reviews` | `review_id` | Append-only human and skill review records. |
| `mvp1_agent_runs` | `run_id` | OpenClaw agent and skill execution logs. |

    `records` 以 SQLite 表为准。所有自动生成结论默认 `review_status=draft` 或 `pending_review`，不得直接成为正式外发内容。

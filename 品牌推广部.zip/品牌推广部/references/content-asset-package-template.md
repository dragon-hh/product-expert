# 内容资产包模板

- Campaign_ID：
- Content_ID：
- Asset_Type：
- Platform：
- Language：
- Title：
- Body_Ref：
- Facts_Ref：
- Risk_Level：
- Version：
- Review_Status：
- 禁用表达检查：
- 产品事实审核点：

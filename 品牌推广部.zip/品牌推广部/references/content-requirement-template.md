# 内容要求单模板

| 字段 | 要求 |
| --- | --- |
| Campaign_ID | 必填 |
| Asset_Type | 社媒、文章、视频、图片、广告标题、邮件草稿 |
| Platform | LinkedIn、YouTube、Reddit、Google、行业媒体等 |
| Language | en-US、es、fr 等 |
| Scenario | 应用场景 |
| CTA | 表单、下载资料、预约演示、联系渠道商 |
| Review_Required | true/false |

# Cron 运行手册

Cron 只做短触发，不承载长规则。具体业务规则在对应 `skills/*/SKILL.md` 和 references 中。

- `weekly-campaign-planning`：每周一 09:00。
- `weekly-feasibility-refresh`：每周一 10:30。
- `weekly-content-generation`：每周二 09:00。
- `weekly-promotion-pack`：每周三 09:00。
- `friday-mvp1-review`：每周五 16:00。

# session send 协作协议

    MVP-1 跨 Agent 消息统一使用 `session send`。消息必须包含 `campaign_id`、`from_agent`、`to_agent`、`task_type`、`input_refs`、`expected_output`、`risk_level`、`review_required`、`writeback_plan`。

    ## 下发消息示例

    ```json
    {
  "campaign_id": "CMP-2026-NA-PL1-001",
  "from_agent": "growth-campaign-planner-agent",
  "to_agent": "growth-data-feasibility-agent",
  "task_type": "feasibility_check",
  "input_refs": {
    "region": "North America",
    "country": "United States",
    "product_line": "PL1",
    "product_model": "MODEL-001"
  },
  "expected_output": "可推广性、库存/交付风险、客户画像、ROI 预估",
  "risk_level": "R2",
  "review_required": true,
  "writeback_plan": {
    "target_table": "mvp1_feasibility_checks",
    "operation": "upsert"
  }
}
    ```

    ## 回传要求

    回传必须包含 `campaign_id`、`owner_agent`、`status`、`summary`、`output_refs`、`risk_level`、`review_required`、`writeback_plan` 和 `next_agent_message`。禁止直接传递客户明细、平台账号凭据或外部系统写回凭据。

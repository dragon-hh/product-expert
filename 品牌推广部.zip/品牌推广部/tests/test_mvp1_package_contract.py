from __future__ import annotations

import json
import sqlite3
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

REQUIRED_AGENT_WORKSPACES = {
    "growth-campaign-planner-agent": "workspace-growth-campaign-planner",
    "growth-data-feasibility-agent": "workspace-growth-data-feasibility",
    "content-asset-agent": "workspace-content-asset",
    "channel-promotion-pack-agent": "workspace-channel-promotion-pack",
}

REQUIRED_TABLES = {
    "mvp1_campaigns",
    "mvp1_platform_channels",
    "mvp1_products",
    "mvp1_feasibility_checks",
    "mvp1_customer_profiles",
    "mvp1_roi_estimates",
    "mvp1_content_requirements",
    "mvp1_content_assets",
    "mvp1_promotion_packs",
    "mvp1_utm_links",
    "mvp1_reviews",
    "mvp1_agent_runs",
}

REQUIRED_JOBS = {
    "weekly-campaign-planning",
    "weekly-feasibility-refresh",
    "weekly-content-generation",
    "weekly-promotion-pack",
    "friday-mvp1-review",
}


class Mvp1PackageContractTest(unittest.TestCase):
    def test_manifest_declares_required_agents_skills_references_and_jobs(self) -> None:
        manifest = self.load_json(ROOT / "package-manifest.json")

        self.assertEqual(manifest["name"], "brand-promotion-mvp1-openclaw-package")
        self.assertEqual(manifest["source_requirement"], "realTask-mvp-1.md")
        self.assertEqual(
            {agent["agent_id"]: agent["workspace"] for agent in manifest["agents"]},
            REQUIRED_AGENT_WORKSPACES,
        )
        self.assertEqual(sum(len(agent["skills"]) for agent in manifest["agents"]), 21)

        for reference in [
            "references/session-send-protocol.md",
            "references/local-gdp-schema.md",
            "references/campaign-brief-template.md",
            "references/content-requirement-template.md",
            "references/content-asset-package-template.md",
            "references/platform-promotion-pack-template.md",
            "references/human-review-checklist.md",
        ]:
            self.assertIn(reference, manifest["references"])
            self.assertTrue((ROOT / reference).exists(), reference)

        jobs = self.load_json(ROOT / "jobs.json")
        self.assertEqual(jobs["version"], 1)
        self.assertEqual({job["name"] for job in jobs["jobs"]}, REQUIRED_JOBS)

    def test_workspaces_have_runtime_files_skills_cron_and_mailboxes(self) -> None:
        manifest = self.load_json(ROOT / "package-manifest.json")

        for agent in manifest["agents"]:
            workspace = ROOT / agent["workspace"]
            for filename in ["AGENTS.md", "IDENTITY.md", "MEMORY.md", "TOOLS.md", "HEARTBEAT.md", "skill-manifest.json", "jobs.json"]:
                self.assertTrue((workspace / filename).exists(), f"{agent['workspace']}/{filename}")
            for dirname in ["skills", "cron", "data/inbox", "data/outbox"]:
                self.assertTrue((workspace / dirname).is_dir(), f"{agent['workspace']}/{dirname}")

            skill_manifest = self.load_json(workspace / "skill-manifest.json")
            self.assertEqual(skill_manifest["agent_id"], agent["agent_id"])
            self.assertEqual([skill["name"] for skill in skill_manifest["skills"]], agent["skills"])
            for skill in agent["skills"]:
                skill_file = workspace / "skills" / skill / "SKILL.md"
                self.assertTrue(skill_file.exists(), str(skill_file))
                content = skill_file.read_text(encoding="utf-8")
                self.assertIn("writeback_plan", content)
                self.assertIn("review_required", content)

            local_jobs = self.load_json(workspace / "jobs.json")["jobs"]
            for job in local_jobs:
                self.assertTrue((workspace / "cron" / f"{job['name']}.json").exists(), job["name"])

    def test_agent_runtime_guidance_uses_operational_language_not_developer_mvp_language(self) -> None:
        manifest = self.load_json(ROOT / "package-manifest.json")

        for agent in manifest["agents"]:
            workspace = ROOT / agent["workspace"]
            runtime_files = [
                workspace / "AGENTS.md",
                workspace / "IDENTITY.md",
                workspace / "MEMORY.md",
                workspace / "HEARTBEAT.md",
                *sorted((workspace / "skills").glob("*/SKILL.md")),
            ]
            for runtime_file in runtime_files:
                content = runtime_file.read_text(encoding="utf-8")
                self.assertNotIn("MVP", content, str(runtime_file))
                self.assertNotIn("MVP-1", content, str(runtime_file))
                self.assertNotIn("统一红线", content, str(runtime_file))

            agents_md = (workspace / "AGENTS.md").read_text(encoding="utf-8")
            self.assertIn("## 业务边界", agents_md)
            self.assertIn("## 禁止动作", agents_md)
            self.assertIn("## 数据与输出约定", agents_md)

    def test_local_gdp_schema_and_sqlite_contain_required_tables(self) -> None:
        schema = (ROOT / "data" / "schema.sql").read_text(encoding="utf-8")
        for table in REQUIRED_TABLES:
            self.assertIn(f"CREATE TABLE IF NOT EXISTS {table}", schema)

        db_path = ROOT / "data" / "gdp.sqlite"
        self.assertTrue(db_path.exists(), "data/gdp.sqlite")
        with sqlite3.connect(db_path) as conn:
            names = {
                row[0]
                for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
            }
        self.assertTrue(REQUIRED_TABLES.issubset(names))

    def test_acceptance_sample_covers_end_to_end_outputs_and_gdp_writeback(self) -> None:
        sample = (ROOT / "MVP1_ACCEPTANCE_SAMPLE.md").read_text(encoding="utf-8")
        for required in [
            "Campaign Brief",
            "区域、国家、平台选择理由",
            "供应链/库存/可交付性校验结果",
            "客户画像和客户分层",
            "ROI 预估",
            "内容要求单",
            "社媒文案",
            "文章草稿",
            "视频脚本",
            "平台适配版本",
            "内容日历",
            "UTM 和 Content_ID 表",
            "发布前审核清单",
            "GDP 写入记录",
            "session send",
        ]:
            self.assertIn(required, sample)

    @staticmethod
    def load_json(path: Path) -> dict:
        return json.loads(path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()

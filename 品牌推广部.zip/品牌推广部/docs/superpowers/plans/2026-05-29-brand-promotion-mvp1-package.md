# Brand Promotion MVP-1 Package Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the `realTask-mvp-1.md` OpenClaw MVP-1 delivery package for the brand development/promotion team.

**Architecture:** A root generator script is the durable source of truth. Generated artifacts include 4 OpenClaw agent workspaces, 21 core skill files, 5 cron jobs, local GDP schema/init assets, session-send protocol references, business templates, and an end-to-end acceptance sample. A unittest contract and package validator check the generated package before completion.

**Tech Stack:** Python standard library, Markdown, JSON, SQLite schema SQL, OpenClaw workspace file conventions.

---

### Task 1: Package Contract Test

**Files:**
- Create: `tests/test_mvp1_package_contract.py`

- [ ] **Step 1: Write the failing test**

```python
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class Mvp1PackageContractTest(unittest.TestCase):
    def test_manifest_declares_required_agents_skills_and_jobs(self):
        manifest = json.loads((ROOT / "package-manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["source_requirement"], "realTask-mvp-1.md")
        self.assertEqual(len(manifest["agents"]), 4)
        self.assertEqual(sum(len(agent["skills"]) for agent in manifest["agents"]), 21)
        jobs = json.loads((ROOT / "jobs.json").read_text(encoding="utf-8"))["jobs"]
        self.assertEqual(len(jobs), 5)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m unittest tests.test_mvp1_package_contract -v`
Expected: FAIL with missing `package-manifest.json`.

### Task 2: Generator and Validator

**Files:**
- Create: `tools/build_mvp1_brand_promotion_package.py`
- Create: `tools/validate_mvp1_brand_promotion_package.py`
- Create: `tools/init_mvp1_gdp.py`

- [ ] **Step 1: Implement the package generator**

Create agent, skill, table, reference, cron, and sample definitions from `realTask-mvp-1.md`.

- [ ] **Step 2: Run generator**

Run: `python tools/build_mvp1_brand_promotion_package.py`
Expected: prints `generated brand promotion mvp1 package`.

- [ ] **Step 3: Run tests**

Run: `python -m unittest tests.test_mvp1_package_contract -v`
Expected: PASS.

### Task 3: GDP Initialization and Final Verification

**Files:**
- Generate: `data/schema.sql`
- Generate: `data/gdp.sqlite`
- Generate: `data/inbox/README.md`
- Generate: `data/outbox/README.md`
- Generate: `data/exports/README.md`

- [ ] **Step 1: Initialize local GDP**

Run: `python tools/init_mvp1_gdp.py`
Expected: creates `data/gdp.sqlite` with all MVP-1 tables.

- [ ] **Step 2: Run package validator**

Run: `python tools/validate_mvp1_brand_promotion_package.py`
Expected: `VALIDATION_OK agents=4 skills=21 jobs=5 tables=12`.

- [ ] **Step 3: Verify acceptance sample**

Run: `python -m unittest tests.test_mvp1_package_contract -v`
Expected: all tests pass and the sample contains campaign brief, feasibility, ROI, content assets, platform pack, UTM, checklist, and GDP writeback evidence.

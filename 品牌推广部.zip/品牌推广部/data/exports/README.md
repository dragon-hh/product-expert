# exports

放置人工审核通过后导出的 Campaign 发布包、内容日历、UTM 表或平台执行清单。MVP-1 不自动发布导出文件。

-- Brand Promotion MVP-1 local GDP schema.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS mvp1_campaigns (
  campaign_id TEXT PRIMARY KEY,
  goal TEXT,
  region TEXT,
  country TEXT,
  product_line TEXT,
  product_model TEXT,
  scenario TEXT,
  owner TEXT,
  status TEXT,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  risk_level TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_campaigns_review_status ON mvp1_campaigns(review_status);

CREATE TABLE IF NOT EXISTS mvp1_platform_channels (
  channel_id TEXT PRIMARY KEY,
  region TEXT,
  country TEXT,
  platform TEXT,
  account_ref TEXT,
  content_format TEXT,
  cta_rule TEXT,
  risk_note TEXT,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  risk_level TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_platform_channels_review_status ON mvp1_platform_channels(review_status);

CREATE TABLE IF NOT EXISTS mvp1_products (
  product_model TEXT PRIMARY KEY,
  product_line TEXT,
  facts_ref TEXT,
  certifications TEXT,
  compatibility TEXT,
  available_regions TEXT,
  risk_note TEXT,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  risk_level TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_products_review_status ON mvp1_products(review_status);

CREATE TABLE IF NOT EXISTS mvp1_feasibility_checks (
  check_id TEXT PRIMARY KEY,
  campaign_id TEXT,
  product_model TEXT,
  inventory_status TEXT,
  deliverability_status TEXT,
  customer_profile_status TEXT,
  roi_status TEXT,
  blocking_reason TEXT,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  risk_level TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_feasibility_checks_review_status ON mvp1_feasibility_checks(review_status);

CREATE INDEX IF NOT EXISTS idx_mvp1_feasibility_checks_campaign_id ON mvp1_feasibility_checks(campaign_id);

CREATE TABLE IF NOT EXISTS mvp1_customer_profiles (
  profile_id TEXT PRIMARY KEY,
  region TEXT,
  country TEXT,
  segment TEXT,
  industry TEXT,
  pain_points TEXT,
  buyer_role TEXT,
  language TEXT,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  risk_level TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_customer_profiles_review_status ON mvp1_customer_profiles(review_status);

CREATE TABLE IF NOT EXISTS mvp1_roi_estimates (
  roi_id TEXT PRIMARY KEY,
  campaign_id TEXT,
  budget REAL,
  estimated_margin REAL,
  estimated_leads INTEGER,
  estimated_rfq INTEGER,
  estimated_orders INTEGER,
  roi REAL,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  risk_level TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_roi_estimates_review_status ON mvp1_roi_estimates(review_status);

CREATE INDEX IF NOT EXISTS idx_mvp1_roi_estimates_campaign_id ON mvp1_roi_estimates(campaign_id);

CREATE TABLE IF NOT EXISTS mvp1_content_requirements (
  requirement_id TEXT PRIMARY KEY,
  campaign_id TEXT,
  asset_type TEXT,
  platform TEXT,
  language TEXT,
  scenario TEXT,
  cta TEXT,
  content_angle TEXT,
  review_required INTEGER,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  risk_level TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_content_requirements_review_status ON mvp1_content_requirements(review_status);

CREATE INDEX IF NOT EXISTS idx_mvp1_content_requirements_campaign_id ON mvp1_content_requirements(campaign_id);

CREATE TABLE IF NOT EXISTS mvp1_content_assets (
  content_id TEXT PRIMARY KEY,
  campaign_id TEXT,
  asset_type TEXT,
  platform TEXT,
  language TEXT,
  title TEXT,
  body_ref TEXT,
  facts_ref TEXT,
  risk_level TEXT,
  version TEXT,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_content_assets_review_status ON mvp1_content_assets(review_status);

CREATE INDEX IF NOT EXISTS idx_mvp1_content_assets_campaign_id ON mvp1_content_assets(campaign_id);

CREATE TABLE IF NOT EXISTS mvp1_promotion_packs (
  pack_id TEXT PRIMARY KEY,
  campaign_id TEXT,
  platform TEXT,
  content_ids TEXT,
  publish_window TEXT,
  utm_ref TEXT,
  checklist_ref TEXT,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  risk_level TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_promotion_packs_review_status ON mvp1_promotion_packs(review_status);

CREATE INDEX IF NOT EXISTS idx_mvp1_promotion_packs_campaign_id ON mvp1_promotion_packs(campaign_id);

CREATE TABLE IF NOT EXISTS mvp1_utm_links (
  utm_id TEXT PRIMARY KEY,
  campaign_id TEXT,
  content_id TEXT,
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  landing_page TEXT,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  risk_level TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_utm_links_review_status ON mvp1_utm_links(review_status);

CREATE INDEX IF NOT EXISTS idx_mvp1_utm_links_campaign_id ON mvp1_utm_links(campaign_id);

CREATE TABLE IF NOT EXISTS mvp1_reviews (
  review_id TEXT PRIMARY KEY,
  entity_type TEXT,
  entity_id TEXT,
  review_type TEXT,
  risk_level TEXT,
  conclusion TEXT,
  reviewer TEXT,
  evidence_ref TEXT,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_reviews_review_status ON mvp1_reviews(review_status);

CREATE TABLE IF NOT EXISTS mvp1_agent_runs (
  run_id TEXT PRIMARY KEY,
  agent_id TEXT,
  skill_id TEXT,
  campaign_id TEXT,
  input_hash TEXT,
  output_ref TEXT,
  status TEXT,
  cost REAL,
  latency_ms INTEGER,
  created_at TEXT,
  updated_at TEXT,
  source_system TEXT,
  source_ref TEXT,
  owner_agent TEXT,
  review_status TEXT,
  risk_level TEXT,
  writeback_lock INTEGER DEFAULT 0,
  evidence_refs TEXT
);

CREATE INDEX IF NOT EXISTS idx_mvp1_agent_runs_review_status ON mvp1_agent_runs(review_status);

CREATE INDEX IF NOT EXISTS idx_mvp1_agent_runs_campaign_id ON mvp1_agent_runs(campaign_id);

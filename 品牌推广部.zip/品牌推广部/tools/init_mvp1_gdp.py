from __future__ import annotations

import sqlite3
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "gdp.sqlite"
SCHEMA_PATH = ROOT / "data" / "schema.sql"


def execute_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))


def seed_acceptance_sample(conn: sqlite3.Connection) -> None:
    now = "2026-05-29T00:00:00+08:00"
    common = {
        "created_at": now,
        "updated_at": now,
        "source_system": "acceptance_sample",
        "source_ref": "MVP1_ACCEPTANCE_SAMPLE.md",
        "owner_agent": "growth-campaign-planner-agent",
        "review_status": "pending_review",
        "risk_level": "R2",
        "writeback_lock": 0,
        "evidence_refs": "MVP1_ACCEPTANCE_SAMPLE.md",
    }

    conn.execute(
        """
        INSERT OR REPLACE INTO mvp1_campaigns
        (campaign_id, goal, region, country, product_line, product_model, scenario, owner, status,
         created_at, updated_at, source_system, source_ref, owner_agent, review_status, risk_level, writeback_lock, evidence_refs)
        VALUES
        (:campaign_id, :goal, :region, :country, :product_line, :product_model, :scenario, :owner, :status,
         :created_at, :updated_at, :source_system, :source_ref, :owner_agent, :review_status, :risk_level, :writeback_lock, :evidence_refs)
        """,
        {
            **common,
            "campaign_id": "CMP-2026-NA-PL1-001",
            "goal": "未来 30 天在北美市场推广 PL1 MODEL-001，获取 B2B 安装商和渠道商线索。",
            "region": "North America",
            "country": "United States",
            "product_line": "PL1",
            "product_model": "MODEL-001",
            "scenario": "B2B installer and channel distributor acquisition",
            "owner": "品牌发展部",
            "status": "pending_review",
        },
    )

    channel_rows = [
        ("CH-NA-LINKEDIN", "LinkedIn", "social", "Book a demo"),
        ("CH-NA-YOUTUBE", "YouTube", "video", "Watch installation guide"),
        ("CH-NA-REDDIT", "Reddit", "community", "Share installation questions"),
    ]
    for channel_id, platform, content_format, cta_rule in channel_rows:
        conn.execute(
            """
            INSERT OR REPLACE INTO mvp1_platform_channels
            (channel_id, region, country, platform, account_ref, content_format, cta_rule, risk_note,
             created_at, updated_at, source_system, source_ref, owner_agent, review_status, risk_level, writeback_lock, evidence_refs)
            VALUES
            (?, 'North America', 'United States', ?, 'manual_account_ref_required', ?, ?, 'manual publishing only',
             ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', 'channel-promotion-pack-agent', 'pending_review', 'R2', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
            """,
            (channel_id, platform, content_format, cta_rule, now, now),
        )

    conn.execute(
        """
        INSERT OR REPLACE INTO mvp1_products
        (product_model, product_line, facts_ref, certifications, compatibility, available_regions, risk_note,
         created_at, updated_at, source_system, source_ref, owner_agent, review_status, risk_level, writeback_lock, evidence_refs)
        VALUES
        ('MODEL-001', 'PL1', 'product_fact_sheet_required', 'north_america_certification_pending',
         'compatibility_pending_review', 'North America pending approval', 'R3 fact review required',
         ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', 'growth-data-feasibility-agent', 'pending_review', 'R3', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
        """,
        (now, now),
    )

    conn.execute(
        """
        INSERT OR REPLACE INTO mvp1_feasibility_checks
        (check_id, campaign_id, product_model, inventory_status, deliverability_status, customer_profile_status, roi_status, blocking_reason,
         created_at, updated_at, source_system, source_ref, owner_agent, review_status, risk_level, writeback_lock, evidence_refs)
        VALUES
        ('CHK-CMP-2026-NA-PL1-001', 'CMP-2026-NA-PL1-001', 'MODEL-001', 'pending_supply_chain_confirmation',
         'pending_deliverability_confirmation', 'profile_summary_available', 'pending_finance_review', 'certification and inventory confirmation required',
         ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', 'growth-data-feasibility-agent', 'pending_review', 'R3', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
        """,
        (now, now),
    )

    profile_rows = [
        ("PROF-NA-INSTALLER", "B2B installer", "installation efficiency, compatibility, support", "owner/operator"),
        ("PROF-NA-DISTRIBUTOR", "channel distributor", "margin, training, stable delivery", "channel manager"),
    ]
    for profile_id, segment, pain_points, buyer_role in profile_rows:
        conn.execute(
            """
            INSERT OR REPLACE INTO mvp1_customer_profiles
            (profile_id, region, country, segment, industry, pain_points, buyer_role, language,
             created_at, updated_at, source_system, source_ref, owner_agent, review_status, risk_level, writeback_lock, evidence_refs)
            VALUES
            (?, 'North America', 'United States', ?, 'B2B energy installation/channel', ?, ?, 'en-US',
             ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', 'growth-data-feasibility-agent', 'pending_review', 'R2', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
            """,
            (profile_id, segment, pain_points, buyer_role, now, now),
        )

    conn.execute(
        """
        INSERT OR REPLACE INTO mvp1_roi_estimates
        (roi_id, campaign_id, budget, estimated_margin, estimated_leads, estimated_rfq, estimated_orders, roi,
         created_at, updated_at, source_system, source_ref, owner_agent, review_status, risk_level, writeback_lock, evidence_refs)
        VALUES
        ('ROI-CMP-2026-NA-PL1-001', 'CMP-2026-NA-PL1-001', 50000, 80000, 180, 36, 8, 1.6,
         ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', 'growth-data-feasibility-agent', 'pending_review', 'R3', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
        """,
        (now, now),
    )

    requirement_rows = [
        ("REQ-LI-SOC-001", "social_copy", "LinkedIn", "Book a demo", "installer/channel pain points"),
        ("REQ-YT-VID-001", "video_script", "YouTube", "Watch installation guide", "installation and channel enablement"),
        ("REQ-RD-DIS-001", "discussion_prompt", "Reddit", "Share installation questions", "community discussion"),
    ]
    for requirement_id, asset_type, platform, cta, angle in requirement_rows:
        conn.execute(
            """
            INSERT OR REPLACE INTO mvp1_content_requirements
            (requirement_id, campaign_id, asset_type, platform, language, scenario, cta, content_angle, review_required,
             created_at, updated_at, source_system, source_ref, owner_agent, review_status, risk_level, writeback_lock, evidence_refs)
            VALUES
            (?, 'CMP-2026-NA-PL1-001', ?, ?, 'en-US', 'B2B installer and channel distributor acquisition', ?, ?, 1,
             ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', 'growth-campaign-planner-agent', 'pending_review', 'R2', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
            """,
            (requirement_id, asset_type, platform, cta, angle, now, now),
        )

    asset_rows = [
        ("CNT-2026-LI-SOC-001", "social_copy", "LinkedIn", "LinkedIn social copy draft"),
        ("CNT-2026-YT-VID-001", "video_script", "YouTube", "YouTube video script draft"),
        ("CNT-2026-RD-DIS-001", "discussion_prompt", "Reddit", "Reddit discussion prompt draft"),
    ]
    for content_id, asset_type, platform, title in asset_rows:
        conn.execute(
            """
            INSERT OR REPLACE INTO mvp1_content_assets
            (content_id, campaign_id, asset_type, platform, language, title, body_ref, facts_ref, risk_level, version,
             created_at, updated_at, source_system, source_ref, owner_agent, review_status, writeback_lock, evidence_refs)
            VALUES
            (?, 'CMP-2026-NA-PL1-001', ?, ?, 'en-US', ?, 'MVP1_ACCEPTANCE_SAMPLE.md', 'product_fact_sheet_required', 'R3', 'v0.1',
             ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', 'content-asset-agent', 'pending_review', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
            """,
            (content_id, asset_type, platform, title, now, now),
        )

    conn.execute(
        """
        INSERT OR REPLACE INTO mvp1_promotion_packs
        (pack_id, campaign_id, platform, content_ids, publish_window, utm_ref, checklist_ref,
         created_at, updated_at, source_system, source_ref, owner_agent, review_status, risk_level, writeback_lock, evidence_refs)
        VALUES
        ('PACK-CMP-2026-NA-PL1-001', 'CMP-2026-NA-PL1-001', 'LinkedIn,YouTube,Reddit',
         'CNT-2026-LI-SOC-001,CNT-2026-YT-VID-001,CNT-2026-RD-DIS-001', 'D1-D5', 'UTM-CMP-2026-NA-PL1-001', 'references/human-review-checklist.md',
         ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', 'channel-promotion-pack-agent', 'pending_review', 'R2', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
        """,
        (now, now),
    )

    utm_rows = [
        ("UTM-LI-001", "CNT-2026-LI-SOC-001", "linkedin", "social"),
        ("UTM-YT-001", "CNT-2026-YT-VID-001", "youtube", "video"),
        ("UTM-RD-001", "CNT-2026-RD-DIS-001", "reddit", "community"),
    ]
    for utm_id, content_id, source, medium in utm_rows:
        conn.execute(
            """
            INSERT OR REPLACE INTO mvp1_utm_links
            (utm_id, campaign_id, content_id, utm_source, utm_medium, utm_campaign, landing_page,
             created_at, updated_at, source_system, source_ref, owner_agent, review_status, risk_level, writeback_lock, evidence_refs)
            VALUES
            (?, 'CMP-2026-NA-PL1-001', ?, ?, ?, 'CMP-2026-NA-PL1-001', 'landing_page_required',
             ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', 'channel-promotion-pack-agent', 'pending_review', 'R2', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
            """,
            (utm_id, content_id, source, medium, now, now),
        )

    conn.execute(
        """
        INSERT OR REPLACE INTO mvp1_reviews
        (review_id, entity_type, entity_id, review_type, risk_level, conclusion, reviewer, evidence_ref,
         created_at, updated_at, source_system, source_ref, owner_agent, review_status, writeback_lock, evidence_refs)
        VALUES
        ('REV-20260529-001', 'campaign_package', 'CMP-2026-NA-PL1-001', 'mvp1_acceptance_review', 'R3',
         'needs_human_before_publish', 'brand_manager', 'MVP1_ACCEPTANCE_SAMPLE.md',
         ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', 'growth-campaign-planner-agent', 'needs_human', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
        """,
        (now, now),
    )

    run_rows = [
        ("RUN-PLANNER-001", "growth-campaign-planner-agent", "campaign-brief-skill", "MVP1_ACCEPTANCE_SAMPLE.md"),
        ("RUN-FEAS-001", "growth-data-feasibility-agent", "roi-estimate-skill", "MVP1_ACCEPTANCE_SAMPLE.md"),
        ("RUN-CONTENT-001", "content-asset-agent", "social-copy-draft-skill", "MVP1_ACCEPTANCE_SAMPLE.md"),
        ("RUN-CHANNEL-001", "channel-promotion-pack-agent", "promotion-pack-export-skill", "MVP1_ACCEPTANCE_SAMPLE.md"),
    ]
    for run_id, agent_id, skill_id, output_ref in run_rows:
        conn.execute(
            """
            INSERT OR REPLACE INTO mvp1_agent_runs
            (run_id, agent_id, skill_id, campaign_id, input_hash, output_ref, status, cost, latency_ms,
             created_at, updated_at, source_system, source_ref, owner_agent, review_status, risk_level, writeback_lock, evidence_refs)
            VALUES
            (?, ?, ?, 'CMP-2026-NA-PL1-001', 'acceptance-sample', ?, 'synced', 0, 0,
             ?, ?, 'acceptance_sample', 'MVP1_ACCEPTANCE_SAMPLE.md', ?, 'synced', 'R2', 0, 'MVP1_ACCEPTANCE_SAMPLE.md')
            """,
            (run_id, agent_id, skill_id, output_ref, now, now, agent_id),
        )


def main() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        execute_schema(conn)
        seed_acceptance_sample(conn)
        conn.commit()
    print(f"initialized {DB_PATH}")


if __name__ == "__main__":
    main()

from __future__ import annotations

import json
import sqlite3
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REQUIRED_ROOT_FILES = [
    "README.md",
    "project.md",
    "package-manifest.json",
    "jobs.json",
    "DELIVERY_CHECKLIST.md",
    "MVP1_ACCEPTANCE_SAMPLE.md",
    "data/schema.sql",
    "data/schema.json",
]
REQUIRED_WORKSPACE_FILES = [
    "AGENTS.md",
    "IDENTITY.md",
    "MEMORY.md",
    "TOOLS.md",
    "HEARTBEAT.md",
    "skill-manifest.json",
    "jobs.json",
    "data/catalog.json",
]
REQUIRED_TABLES = {
    "mvp1_campaigns",
    "mvp1_platform_channels",
    "mvp1_products",
    "mvp1_feasibility_checks",
    "mvp1_customer_profiles",
    "mvp1_roi_estimates",
    "mvp1_content_requirements",
    "mvp1_content_assets",
    "mvp1_promotion_packs",
    "mvp1_utm_links",
    "mvp1_reviews",
    "mvp1_agent_runs",
}


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def fail(message: str) -> None:
    raise SystemExit(f"VALIDATION_FAILED: {message}")


def main() -> None:
    for filename in REQUIRED_ROOT_FILES:
        if not (ROOT / filename).exists():
            fail(f"missing root file {filename}")

    manifest = load_json(ROOT / "package-manifest.json")
    if manifest.get("source_requirement") != "realTask-mvp-1.md":
        fail("manifest source requirement mismatch")
    agents = manifest.get("agents", [])
    if len(agents) != 4:
        fail(f"expected 4 agents, found {len(agents)}")

    jobs = load_json(ROOT / "jobs.json")
    if jobs.get("version") != 1 or len(jobs.get("jobs", [])) != 5:
        fail("expected 5 root jobs")
    root_job_names = {job["name"] for job in jobs["jobs"]}

    references = manifest.get("references", [])
    if len(references) < 10:
        fail("too few references")
    for reference in references:
        if not (ROOT / reference).exists():
            fail(f"missing reference {reference}")

    skill_count = 0
    for agent in agents:
        workspace = ROOT / agent["workspace"]
        if not workspace.is_dir():
            fail(f"missing workspace {agent['workspace']}")
        for filename in REQUIRED_WORKSPACE_FILES:
            if not (workspace / filename).exists():
                fail(f"missing {agent['workspace']}/{filename}")
        for dirname in ["skills", "cron", "data/inbox", "data/outbox"]:
            if not (workspace / dirname).is_dir():
                fail(f"missing {agent['workspace']}/{dirname}")

        skill_manifest = load_json(workspace / "skill-manifest.json")
        if skill_manifest["agent_id"] != agent["agent_id"]:
            fail(f"skill manifest agent mismatch for {agent['workspace']}")
        skill_names = [skill["name"] for skill in skill_manifest["skills"]]
        if skill_names != agent["skills"]:
            fail(f"skill list mismatch for {agent['workspace']}")
        for skill in skill_names:
            skill_path = workspace / "skills" / skill / "SKILL.md"
            if not skill_path.exists():
                fail(f"missing skill file {skill_path}")
            content = skill_path.read_text(encoding="utf-8")
            for required in ["writeback_plan", "review_required", "scope_blocked"]:
                if required not in content:
                    fail(f"{skill_path} missing {required}")
        skill_count += len(skill_names)

        local_jobs = load_json(workspace / "jobs.json").get("jobs", [])
        for job in local_jobs:
            if job["name"] not in root_job_names:
                fail(f"workspace job {job['name']} missing from root jobs")
            if not (workspace / "cron" / f"{job['name']}.json").exists():
                fail(f"missing cron file {job['name']} for {agent['workspace']}")

        catalog = load_json(workspace / "data" / "catalog.json")
        for table in agent["data_tables"]:
            if table not in catalog["tables"]:
                fail(f"{table} not declared in {agent['workspace']} catalog")

    if skill_count != 21:
        fail(f"expected 21 skills, found {skill_count}")

    schema = (ROOT / "data" / "schema.sql").read_text(encoding="utf-8")
    for table in REQUIRED_TABLES:
        if f"CREATE TABLE IF NOT EXISTS {table}" not in schema:
            fail(f"schema missing {table}")

    db_path = ROOT / "data" / "gdp.sqlite"
    if not db_path.exists():
        fail("missing data/gdp.sqlite; run tools/init_mvp1_gdp.py")
    with sqlite3.connect(db_path) as conn:
        names = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if not REQUIRED_TABLES.issubset(names):
        fail("sqlite database missing required tables")

    print(f"VALIDATION_OK agents={len(agents)} skills={skill_count} jobs={len(jobs['jobs'])} tables={len(REQUIRED_TABLES)}")


if __name__ == "__main__":
    main()

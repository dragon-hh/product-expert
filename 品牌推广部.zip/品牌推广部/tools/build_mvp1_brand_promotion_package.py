from __future__ import annotations

import json
import textwrap
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
GENERATED_AT = "2026-05-29T00:00:00+08:00"
CREATED_AT_MS = int(datetime(2026, 5, 29, tzinfo=timezone(timedelta(hours=8))).timestamp() * 1000)


COMMON_COLUMNS = {
    "created_at": "TEXT",
    "updated_at": "TEXT",
    "source_system": "TEXT",
    "source_ref": "TEXT",
    "owner_agent": "TEXT",
    "review_status": "TEXT",
    "risk_level": "TEXT",
    "writeback_lock": "INTEGER DEFAULT 0",
    "evidence_refs": "TEXT",
}


TABLES: dict[str, dict[str, object]] = {
    "mvp1_campaigns": {
        "pk": "campaign_id",
        "description": "Campaign brief and planning status.",
        "fields": {
            "goal": "TEXT",
            "region": "TEXT",
            "country": "TEXT",
            "product_line": "TEXT",
            "product_model": "TEXT",
            "scenario": "TEXT",
            "owner": "TEXT",
            "status": "TEXT",
        },
    },
    "mvp1_platform_channels": {
        "pk": "channel_id",
        "description": "Approved platform channel library.",
        "fields": {
            "region": "TEXT",
            "country": "TEXT",
            "platform": "TEXT",
            "account_ref": "TEXT",
            "content_format": "TEXT",
            "cta_rule": "TEXT",
            "risk_note": "TEXT",
        },
    },
    "mvp1_products": {
        "pk": "product_model",
        "description": "Product facts, certifications, compatibility, and available regions.",
        "fields": {
            "product_line": "TEXT",
            "facts_ref": "TEXT",
            "certifications": "TEXT",
            "compatibility": "TEXT",
            "available_regions": "TEXT",
            "risk_note": "TEXT",
        },
    },
    "mvp1_feasibility_checks": {
        "pk": "check_id",
        "description": "Inventory, supply, deliverability, customer-profile, and ROI feasibility checks.",
        "fields": {
            "campaign_id": "TEXT",
            "product_model": "TEXT",
            "inventory_status": "TEXT",
            "deliverability_status": "TEXT",
            "customer_profile_status": "TEXT",
            "roi_status": "TEXT",
            "blocking_reason": "TEXT",
        },
    },
    "mvp1_customer_profiles": {
        "pk": "profile_id",
        "description": "Customer profile and segmentation summaries without exporting customer details.",
        "fields": {
            "region": "TEXT",
            "country": "TEXT",
            "segment": "TEXT",
            "industry": "TEXT",
            "pain_points": "TEXT",
            "buyer_role": "TEXT",
            "language": "TEXT",
        },
    },
    "mvp1_roi_estimates": {
        "pk": "roi_id",
        "description": "Budget, margin, lead, RFQ, order, and ROI estimates.",
        "fields": {
            "campaign_id": "TEXT",
            "budget": "REAL",
            "estimated_margin": "REAL",
            "estimated_leads": "INTEGER",
            "estimated_rfq": "INTEGER",
            "estimated_orders": "INTEGER",
            "roi": "REAL",
        },
    },
    "mvp1_content_requirements": {
        "pk": "requirement_id",
        "description": "Content asset requirements by campaign, platform, language, scenario, and CTA.",
        "fields": {
            "campaign_id": "TEXT",
            "asset_type": "TEXT",
            "platform": "TEXT",
            "language": "TEXT",
            "scenario": "TEXT",
            "cta": "TEXT",
            "content_angle": "TEXT",
            "review_required": "INTEGER",
        },
    },
    "mvp1_content_assets": {
        "pk": "content_id",
        "description": "Generated draft content assets with fact references and review status.",
        "fields": {
            "campaign_id": "TEXT",
            "asset_type": "TEXT",
            "platform": "TEXT",
            "language": "TEXT",
            "title": "TEXT",
            "body_ref": "TEXT",
            "facts_ref": "TEXT",
            "risk_level": "TEXT",
            "version": "TEXT",
        },
    },
    "mvp1_promotion_packs": {
        "pk": "pack_id",
        "description": "Human-reviewable platform promotion packs.",
        "fields": {
            "campaign_id": "TEXT",
            "platform": "TEXT",
            "content_ids": "TEXT",
            "publish_window": "TEXT",
            "utm_ref": "TEXT",
            "checklist_ref": "TEXT",
        },
    },
    "mvp1_utm_links": {
        "pk": "utm_id",
        "description": "UTM, Content_ID, Campaign_ID mapping.",
        "fields": {
            "campaign_id": "TEXT",
            "content_id": "TEXT",
            "utm_source": "TEXT",
            "utm_medium": "TEXT",
            "utm_campaign": "TEXT",
            "landing_page": "TEXT",
        },
    },
    "mvp1_reviews": {
        "pk": "review_id",
        "description": "Append-only human and skill review records.",
        "fields": {
            "entity_type": "TEXT",
            "entity_id": "TEXT",
            "review_type": "TEXT",
            "risk_level": "TEXT",
            "conclusion": "TEXT",
            "reviewer": "TEXT",
            "evidence_ref": "TEXT",
        },
    },
    "mvp1_agent_runs": {
        "pk": "run_id",
        "description": "OpenClaw agent and skill execution logs.",
        "fields": {
            "agent_id": "TEXT",
            "skill_id": "TEXT",
            "campaign_id": "TEXT",
            "input_hash": "TEXT",
            "output_ref": "TEXT",
            "status": "TEXT",
            "cost": "REAL",
            "latency_ms": "INTEGER",
        },
    },
}


AGENTS: list[dict[str, object]] = [
    {
        "agent_id": "growth-campaign-planner-agent",
        "name": "增长战役规划 Agent",
        "workspace": "workspace-growth-campaign-planner",
        "owner": "品牌发展部增长负责人",
        "session_target": "growth-campaign-planner",
        "scope": "从企业增长目标形成 Campaign brief、区域/国家/平台推荐、产品/场景候选、内容需求单，并负责跨 agent 拆解与最终汇总。",
        "skills": {
            "campaign-brief-skill": "根据增长目标生成 Campaign brief。",
            "region-country-prioritize-skill": "选择区域、国家和优先级。",
            "platform-channel-select-skill": "从平台渠道库选择平台组合。",
            "product-scenario-select-skill": "选择产品线、型号和应用场景。",
            "content-requirement-skill": "定义内容资产类型、语言、平台格式和 CTA。",
        },
        "tables": [
            "mvp1_campaigns",
            "mvp1_platform_channels",
            "mvp1_products",
            "mvp1_content_requirements",
            "mvp1_agent_runs",
            "mvp1_reviews",
        ],
        "rules": [
            "所有 Campaign 必须先有增长目标、目标区域、产品线/型号、预算、周期和审核状态。",
            "规划 Agent 只生成草案、推荐和任务拆解，不自动发布内容。",
            "向其他 Agent 下发任务时必须使用 `session send` 结构化消息。",
        ],
    },
    {
        "agent_id": "growth-data-feasibility-agent",
        "name": "数据与可行性校验 Agent",
        "workspace": "workspace-growth-data-feasibility",
        "owner": "品牌发展部数据与供应链接口人",
        "session_target": "growth-data-feasibility",
        "scope": "校验产品事实、认证、库存、供应链、区域可售性、客户画像、客户分层、利润与 ROI，并标记阻断项和待人工确认项。",
        "skills": {
            "product-fact-check-skill": "校验产品型号、参数、认证、兼容性资料是否完整。",
            "availability-check-skill": "校验库存、供应链、区域可售性、可交付性。",
            "customer-profile-select-skill": "选择客户画像和客户清单摘要。",
            "roi-estimate-skill": "预估成本、毛利、线索/RFQ/订单贡献。",
            "feasibility-risk-flag-skill": "标记数据缺口、不可推广项、需人工确认项。",
        },
        "tables": [
            "mvp1_campaigns",
            "mvp1_products",
            "mvp1_feasibility_checks",
            "mvp1_customer_profiles",
            "mvp1_roi_estimates",
            "mvp1_agent_runs",
            "mvp1_reviews",
        ],
        "rules": [
            "产品可推广性必须经过库存、供应链、区域可售性、可交付性和 ROI 检查。",
            "客户清单只做画像和分层，不导出明细，不做主动触达。",
            "数据缺口、认证不全、交付不确定、ROI 低于阈值时必须进入人工审核。",
        ],
    },
    {
        "agent_id": "content-asset-agent",
        "name": "内容资产生成 Agent",
        "workspace": "workspace-content-asset",
        "owner": "品牌发展部内容负责人",
        "session_target": "content-asset",
        "scope": "根据 Campaign brief 和可行性结果生成社媒文案、文章草稿、视频脚本、图片提示词、本地化内容和内容风险审核清单。",
        "skills": {
            "social-copy-draft-skill": "生成社媒文案。",
            "article-draft-skill": "生成 SEO/行业文章草稿。",
            "video-script-skill": "生成营销视频、安装视频、调试视频、培训视频脚本。",
            "image-prompt-skill": "生成图片设计 brief 或 AI 图片提示词。",
            "localized-content-skill": "生成多语言或区域本地化初稿。",
            "content-risk-review-skill": "检查产品事实、版权、禁用表达、R3/R4 风险。",
        },
        "tables": [
            "mvp1_campaigns",
            "mvp1_products",
            "mvp1_customer_profiles",
            "mvp1_content_requirements",
            "mvp1_content_assets",
            "mvp1_reviews",
            "mvp1_agent_runs",
        ],
        "rules": [
            "内容只能生成草稿和审核清单，不自动对外发布。",
            "产品参数、认证、兼容性、安装调试、故障排查内容必须进入审核。",
            "所有内容资产必须标注适用平台、语言、区域、产品型号、版本和事实来源。",
        ],
    },
    {
        "agent_id": "channel-promotion-pack-agent",
        "name": "渠道推广编排 Agent",
        "workspace": "workspace-channel-promotion-pack",
        "owner": "品牌发展部渠道运营负责人",
        "session_target": "channel-promotion-pack",
        "scope": "将内容资产适配为平台发布格式、内容日历、UTM、Content_ID、发布检查表和人工可执行的 Campaign 发布包。",
        "skills": {
            "platform-format-adapt-skill": "根据平台格式适配内容。",
            "content-calendar-skill": "生成内容日历和发布时间建议。",
            "utm-generate-skill": "生成 UTM、Content_ID、Campaign_ID 映射。",
            "publishing-checklist-skill": "生成发布前检查清单。",
            "promotion-pack-export-skill": "汇总所有平台内容和执行清单。",
        },
        "tables": [
            "mvp1_campaigns",
            "mvp1_platform_channels",
            "mvp1_content_assets",
            "mvp1_promotion_packs",
            "mvp1_utm_links",
            "mvp1_reviews",
            "mvp1_agent_runs",
        ],
        "rules": [
            "推广包只输出人工审核/发布材料，不调用平台自动发布 API。",
            "所有 Campaign 输出必须有 Campaign_ID、Content_ID、UTM 和审核状态。",
            "仅设计后续信号采集字段，不处理询盘/RFQ/订单闭环。",
        ],
    },
]


JOBS = [
    ("weekly-campaign-planning", "0 9 * * 1", "growth-campaign-planner-agent", ["campaign-brief-skill", "region-country-prioritize-skill", "platform-channel-select-skill", "product-scenario-select-skill", "content-requirement-skill"], "生成本周 Campaign brief 草案、区域/平台/产品/场景推荐和内容需求单。"),
    ("weekly-feasibility-refresh", "30 10 * * 1", "growth-data-feasibility-agent", ["product-fact-check-skill", "availability-check-skill", "customer-profile-select-skill", "roi-estimate-skill", "feasibility-risk-flag-skill"], "刷新产品可推广性、客户画像和 ROI 预估，输出阻断项和待人工确认项。"),
    ("weekly-content-generation", "0 9 * * 2", "content-asset-agent", ["social-copy-draft-skill", "article-draft-skill", "video-script-skill", "image-prompt-skill", "localized-content-skill", "content-risk-review-skill"], "根据已通过 brief 生成内容资产草稿和内容风险审核清单。"),
    ("weekly-promotion-pack", "0 9 * * 3", "channel-promotion-pack-agent", ["platform-format-adapt-skill", "content-calendar-skill", "utm-generate-skill", "publishing-checklist-skill", "promotion-pack-export-skill"], "生成平台发布包、内容日历、UTM 表和发布前检查表。"),
    ("friday-mvp1-review", "0 16 * * 5", "growth-campaign-planner-agent", ["campaign-brief-skill", "content-requirement-skill"], "汇总本周 Campaign 包、缺口、风险、待审核项和下一轮任务拆解。"),
]


AGENT_BOUNDARY_RULES = [
    "只处理增长战役规划、内容生产与推广相关任务，不处理客户消息闭环。",
    "产品可推广性必须经过库存、供应链、区域可售性、可交付性和 ROI 检查。",
    "客户清单只做画像和分层，不导出明细，不做主动触达。",
    "产品参数、认证、兼容性、安装调试、故障排查内容必须进入审核。",
    "所有 Campaign 输出必须有 Campaign_ID、Content_ID、UTM 和审核状态。",
    "所有内容资产必须标注适用平台、语言、区域、产品型号、版本和事实来源。",
]


AGENT_FORBIDDEN_ACTIONS = [
    "不得自动发布内容或调用平台发布 API。",
    "不得自动发送邮件。",
    "不得自动处理客户邮件、私信、询盘、RFQ 或订单闭环。",
    "不得自动写回 CRM、ERP、PLM、商城、积分、售后或运维系统。",
    "不得把未审核的产品参数、认证、兼容性、安装调试、故障排查内容作为正式结论输出。",
]


def clean(text: str) -> str:
    normalized = textwrap.dedent(text).strip("\n")
    lines = normalized.splitlines()
    lines = [line[8:] if line.startswith("        ") else line for line in lines]
    return "\n".join(lines).strip() + "\n"


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def agent_by_id(agent_id: str) -> dict[str, object]:
    return next(agent for agent in AGENTS if agent["agent_id"] == agent_id)


def job_id(name: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"brand-promotion-mvp1/{name}"))


def build_job(name: str, expr: str, agent_id: str, skills: list[str], message: str) -> dict[str, object]:
    agent = agent_by_id(agent_id)
    return {
        "id": job_id(name),
        "name": name,
        "agent": {
            "id": agent["agent_id"],
            "name": agent["name"],
            "workspace": agent["workspace"],
            "sessionTarget": agent["session_target"],
        },
        "enabled": True,
        "createdAtMs": CREATED_AT_MS,
        "updatedAtMs": CREATED_AT_MS,
        "schedule": {
            "kind": "cron",
            "expr": expr,
            "tz": "Asia/Shanghai",
            "staggerMs": 0,
        },
        "skills": skills,
        "sessionTarget": "isolated",
        "wakeMode": "now",
        "payload": {
            "kind": "agentTurn",
            "message": message + " 输出 Campaign_ID、Content_ID/UTM 映射、风险等级、review_required、writeback_plan 和人工审核事项；不得自动发布、不得自动发送邮件、不得写 CRM/ERP。",
        },
        "delivery": {
            "mode": "announce",
            "channel": "feishu",
            "bestEffort": True,
        },
        "state": {},
    }


def build_jobs() -> list[dict[str, object]]:
    return [build_job(*job) for job in JOBS]


def schema_sql() -> str:
    blocks = [
        "-- Brand Promotion MVP-1 local GDP schema.",
        "PRAGMA foreign_keys = ON;",
    ]
    for table_name, config in TABLES.items():
        pk = str(config["pk"])
        fields = dict(config["fields"])
        columns = [f"  {pk} TEXT PRIMARY KEY"]
        for field, field_type in fields.items():
            if field == pk:
                continue
            columns.append(f"  {field} {field_type}")
        for field, field_type in COMMON_COLUMNS.items():
            if field in fields or field == pk:
                continue
            columns.append(f"  {field} {field_type}")
        blocks.append(f"CREATE TABLE IF NOT EXISTS {table_name} (\n" + ",\n".join(columns) + "\n);")
        blocks.append(f"CREATE INDEX IF NOT EXISTS idx_{table_name}_review_status ON {table_name}(review_status);")
        if "campaign_id" in fields and pk != "campaign_id":
            blocks.append(f"CREATE INDEX IF NOT EXISTS idx_{table_name}_campaign_id ON {table_name}(campaign_id);")
    return "\n\n".join(blocks) + "\n"


def schema_json() -> dict[str, object]:
    return {
        "generated_at": GENERATED_AT,
        "database": "data/gdp.sqlite",
        "tables": {
            table_name: {
                "description": config["description"],
                "primary_key": config["pk"],
                "fields": config["fields"],
                "common_columns": COMMON_COLUMNS,
            }
            for table_name, config in TABLES.items()
        },
    }


def workspace_catalog(agent: dict[str, object]) -> dict[str, object]:
    return {
        "owner_agent": agent["agent_id"],
        "gdp_database": "../../data/gdp.sqlite",
        "schema_ref": "../../data/schema.sql",
        "tables": {
            table: {
                "primary_key": TABLES[table]["pk"],
                "description": TABLES[table]["description"],
                "review_required": True,
            }
            for table in agent["tables"]
        },
    }


def root_readme() -> str:
    rows = "\n".join(f"| `{agent['agent_id']}` | `{agent['workspace']}` | {agent['scope']} |" for agent in AGENTS)
    return clean(f"""
        # 品牌发展部 AI 作战团队 MVP-1 OpenClaw 交付包

        本目录按 `realTask-mvp-1.md` 交付 MVP-1：增长战役规划流 + 内容生产与推广流。目标是从一个企业增长目标产出可审核、可发布、可追踪的全球内容推广战役包。

        ## MVP-1 边界

        - 做：Campaign brief、区域/国家/平台策略、产品/客户/场景选择、ROI 预估、内容草稿、平台发布包。
        - 不做：客户消息自动处理、销售闭环、交付、运维、商城、积分、CRM/ERP 自动写回。
        - 所有内容先生成草稿和发布清单，人工审核后再发布。

        ## 工作区

        | Agent | 工作区 | 主责 |
        | --- | --- | --- |
        {rows}

        ## 入口

        - `package-manifest.json`：交付包总索引。
        - `jobs.json`：5 个 MVP-1 cron 注册清单。
        - `data/schema.sql`：本地 GDP SQLite schema。
        - `tools/init_mvp1_gdp.py`：初始化 `data/gdp.sqlite` 并写入验收样例记录。
        - `references/session-send-protocol.md`：跨 agent 协作协议。
        - `MVP1_ACCEPTANCE_SAMPLE.md`：端到端验收样例。

        ## 验证

        ```powershell
        python .\\tools\\init_mvp1_gdp.py
        python .\\tools\\validate_mvp1_brand_promotion_package.py
        python -m unittest tests.test_mvp1_package_contract -v
        ```
    """)


def project_md() -> str:
    return clean(f"""
        # 品牌推广部 MVP-1 项目说明

        ## 项目定位

        MVP-1 是品牌发展部 AI 作战团队的低风险前端增长包：输入企业增长目标，输出 Campaign brief、可行性校验、内容资产草稿、平台推广包、UTM/Content_ID、人工审核清单和 GDP 记录。

        ## 资产统计

        - Agent 工作区：{len(AGENTS)} 个
        - Core skill：{sum(len(agent['skills']) for agent in AGENTS)} 个
        - Cron：{len(JOBS)} 个
        - 本地 GDP 表：{len(TABLES)} 张
        - 公共 reference：11 个

        ## 最小运行路径

        1. `growth-campaign-planner-agent` 接收增长目标并生成 Campaign brief。
        2. 通过 `session send` 请求 `growth-data-feasibility-agent` 做产品/供应链/客户/ROI 校验。
        3. 可行性通过后请求 `content-asset-agent` 生成内容资产草稿和审核清单。
        4. 请求 `channel-promotion-pack-agent` 输出平台发布包、内容日历、UTM 和发布前检查表。
        5. 规划 Agent 汇总 Campaign 发布包，所有结果写入本地 GDP 并保持待人工审核状态。
    """)


def delivery_checklist() -> str:
    agent_lines = "\n".join(f"- [x] `{agent['agent_id']}`：`{agent['workspace']}/`、{len(agent['skills'])} 个 skill、`cron/`、`data/inbox/`、`data/outbox/`。" for agent in AGENTS)
    table_lines = "\n".join(f"- [x] `{table}`：{config['description']}" for table, config in TABLES.items())
    return clean(f"""
        # MVP-1 交付清单

        ## Agent 工作区

        {agent_lines}

        ## Core skills

        - [x] 规划 Agent：5 个。
        - [x] 可行性 Agent：5 个。
        - [x] 内容 Agent：6 个。
        - [x] 渠道 Agent：5 个。

        ## Cron

        - [x] `weekly-campaign-planning`
        - [x] `weekly-feasibility-refresh`
        - [x] `weekly-content-generation`
        - [x] `weekly-promotion-pack`
        - [x] `friday-mvp1-review`

        ## 本地 GDP

        {table_lines}

        ## 协议与模板

        - [x] `references/session-send-protocol.md`
        - [x] `references/campaign-brief-template.md`
        - [x] `references/content-requirement-template.md`
        - [x] `references/content-asset-package-template.md`
        - [x] `references/platform-promotion-pack-template.md`
        - [x] `references/human-review-checklist.md`
        - [x] `MVP1_ACCEPTANCE_SAMPLE.md`
    """)


def package_manifest(all_jobs: list[dict[str, object]]) -> dict[str, object]:
    return {
        "name": "brand-promotion-mvp1-openclaw-package",
        "version": "0.1.0",
        "source_requirement": "realTask-mvp-1.md",
        "generated_at": GENERATED_AT,
        "mvp_scope": "增长战役规划 + 内容生产与推广；不自动发布、不自动发送、不写 CRM/ERP。",
        "agents": [
            {
                "agent_id": agent["agent_id"],
                "agent_name": agent["name"],
                "workspace": agent["workspace"],
                "session_target": agent["session_target"],
                "owner": agent["owner"],
                "skills": list(agent["skills"].keys()),
                "data_tables": agent["tables"],
                "jobs": [job["name"] for job in all_jobs if job["agent"]["id"] == agent["agent_id"]],
            }
            for agent in AGENTS
        ],
        "references": [f"references/{name}" for name in reference_texts()],
        "unified_jobs": "jobs.json",
        "local_gdp": {
            "database": "data/gdp.sqlite",
            "schema": "data/schema.sql",
            "initializer": "tools/init_mvp1_gdp.py",
        },
    }


def agents_md(agent: dict[str, object]) -> str:
    rules = "\n".join(f"- {rule}" for rule in agent["rules"])
    boundary_rules = "\n".join(f"- {rule}" for rule in AGENT_BOUNDARY_RULES)
    forbidden_actions = "\n".join(f"- {rule}" for rule in AGENT_FORBIDDEN_ACTIONS)
    skills = "\n".join(f"- `{name}`：{desc}" for name, desc in agent["skills"].items())
    return clean(f"""
        # AGENTS.md - {agent['name']}

        ## 业务定位

        {agent['scope']}

        ## 业务边界

        {boundary_rules}

        ## 禁止动作

        {forbidden_actions}

        ## 本域规则

        {rules}

        ## 数据与输出约定

        - 本地 GDP 统一使用根目录 `data/gdp.sqlite`，本工作区通过 `data/catalog.json` 声明可读写表。
        - `data/inbox/*.jsonl` 接收人工录入、源系统摘要或上游 Agent 输出。
        - `data/outbox/*.jsonl` 只保存待审核输出包、`writeback_plan` 和发送给下游 Agent 的 `session send` payload。
        - 每次输出必须包含 `campaign_id`、风险等级、审核状态、证据引用、`review_required`、`writeback_plan`。

        ## 技能

        {skills}
    """)


def identity_md(agent: dict[str, object]) -> str:
    return clean(f"""
        # IDENTITY.md - {agent['name']}

        - Agent ID：`{agent['agent_id']}`
        - 会话目标：`{agent['session_target']}`
        - Owner：{agent['owner']}

        ## 主责

        {agent['scope']}

        ## 服务边界

        本 Agent 只处理增长战役规划、可行性校验、内容草稿或推广包编排中的本域任务。不得自动发布内容、自动发送邮件、自动处理客户私信或写回 CRM/ERP。
    """)


def memory_md(agent: dict[str, object]) -> str:
    boundary_rules = "\n".join(f"- {rule}" for rule in AGENT_BOUNDARY_RULES)
    forbidden_actions = "\n".join(f"- {rule}" for rule in AGENT_FORBIDDEN_ACTIONS)
    rules = "\n".join(f"- {rule}" for rule in agent["rules"])
    return clean(f"""
        # MEMORY.md - {agent['name']}

        ## 长期边界

        {boundary_rules}

        ## 禁止动作

        {forbidden_actions}

        ## 本 Agent 长期规则

        {rules}

        ## 审核口径

        - R1：低风险结构化整理，可归档但仍保留来源。
        - R2：常规 Campaign/内容草稿，需业务负责人审核。
        - R3：产品参数、认证、安装调试、ROI、客户画像，需专业负责人审核。
        - R4：客户承诺、合规、对外发布敏感表达，必须人工确认，不得自动发布。

        ## 记忆沉淀

        可沉淀内容先写入 `mvp1_reviews` 或 `mvp1_agent_runs` 的证据引用，人工确认后再更新本文件。
    """)


def tools_md(agent: dict[str, object]) -> str:
    return clean(f"""
        # TOOLS.md - {agent['name']}

        ## 本地数据

        - 读 GDP schema：`../../data/schema.sql`。
        - 读 GDP 数据：`../../data/gdp.sqlite`。
        - 读本域目录：`data/catalog.json`。
        - 收输入：`data/inbox/*.jsonl`。
        - 写待审核输出：`data/outbox/*.jsonl`。

        ## 协同

        - 跨 Agent 任务统一使用 `session send`。
        - 消息字段必须包含 `campaign_id`、`from_agent`、`to_agent`、`task_type`、`input_refs`、`expected_output`、`risk_level`、`review_required`、`writeback_plan`。
        - 本 Agent 不直接读取其他工作区原始 inbox/outbox。
    """)


def heartbeat_md(agent: dict[str, object]) -> str:
    return clean(f"""
        # HEARTBEAT.md - {agent['name']}

        心跳只做轻量运行检查：

        1. 检查 `data/outbox/*.jsonl` 是否有超过 3 个工作日的待审核 Campaign 输出。
        2. 检查 `mvp1_agent_runs` 是否存在失败或超时运行。
        3. 检查 `mvp1_reviews` 是否存在 R3/R4 且未给出人工结论的事项。
        4. 检查 `data/inbox/*.jsonl` 是否有未归一化输入。

        输出 `HEARTBEAT_OK` 或事项清单；不得生成新 Campaign，也不得发布内容。
    """)


def skill_manifest(agent: dict[str, object], agent_jobs: list[dict[str, object]]) -> dict[str, object]:
    return {
        "agent_id": agent["agent_id"],
        "agent_name": agent["name"],
        "workspace": agent["workspace"],
        "session_target": agent["session_target"],
        "skills": [
            {
                "name": name,
                "path": f"{agent['workspace']}/skills/{name}/SKILL.md",
                "description": desc,
            }
            for name, desc in agent["skills"].items()
        ],
        "data_tables": [
            {
                "name": table,
                "primary_key": TABLES[table]["pk"],
                "schema_ref": "data/schema.sql",
            }
            for table in agent["tables"]
        ],
        "jobs": [{"name": job["name"], "schedule": job["schedule"], "skills": job["skills"]} for job in agent_jobs],
    }


def skill_md(agent: dict[str, object], skill_name: str, description: str) -> str:
    tables = ", ".join(f"`{table}`" for table in agent["tables"])
    dispatch_note = ""
    if agent["agent_id"] == "growth-campaign-planner-agent":
        dispatch_note = "- 如需下游协作，按 `references/session-send-protocol.md` 生成 `session send` payload。\n"
    if "risk" in skill_name or "review" in skill_name or "fact" in skill_name or "availability" in skill_name or "roi" in skill_name:
        review_level = "R3"
    elif "publishing" in skill_name or "promotion" in skill_name or "utm" in skill_name:
        review_level = "R2"
    else:
        review_level = "R2"
    desc_yaml = description.replace('"', "'")
    return clean(f"""
        ---
        name: {skill_name}
        description: "{desc_yaml}"
        ---

        # {skill_name}

        ## Purpose

        {description}

        ## Owner

        - Agent：{agent['name']}（`{agent['agent_id']}`）
        - Workspace：`{agent['workspace']}`

        ## Inputs

        - 用户请求、cron payload 或上游 `session send` 任务。
        - `campaign_id`、增长目标、区域/国家、产品线/型号、平台、预算、周期、目标线索/RFQ。
        - 本地 GDP：{tables}。
        - 公共规则：`references/mvp1-scope-rules.md`、`references/local-gdp-schema.md`、`references/output-templates.md`。

        ## Procedure

        1. 读取 `data/catalog.json`，确认本 skill 可使用的 GDP 表和主键。
        2. 读取 `data/inbox/*.jsonl` 或上游 payload 中的 `input_refs`。
        3. 校验 `campaign_id`、来源证据、审核状态和风险等级。
        4. 执行本 skill 的业务动作：{description}
        5. 标注事实来源、适用区域/平台/语言、产品型号、版本和数据缺口。
        6. 对产品事实、认证、兼容性、安装调试、ROI、客户画像或对外发布内容标记 `review_required=true`。
        {dispatch_note}7. 只输出草稿、建议、发布包或写回计划，不自动发布、不自动发送、不写 CRM/ERP。

        ## Outputs

        必须同时输出：

        ```json
        {{
          "campaign_id": "CMP-YYYY-REGION-PRODUCT-NNN",
          "skill_id": "{skill_name}",
          "owner_agent": "{agent['agent_id']}",
          "status": "draft|pending_review|approved|blocked",
          "risk_level": "{review_level}",
          "review_required": true,
          "source_refs": [],
          "result": {{}},
          "writeback_plan": [],
          "next_agent_message": null
        }}
        ```

        ## Error Handling

        - 缺少产品事实、库存、可交付性、客户画像或预算时，返回 `insufficient_data` 并列出缺口。
        - 发现自动发布、自动发送、CRM/ERP 写回诉求时，返回 `scope_blocked`。
        - 发现人工锁定字段时，不覆盖原值，只追加待审核建议。
    """)


def reference_texts() -> dict[str, str]:
    session_payload = json.dumps(
        {
            "campaign_id": "CMP-2026-NA-PL1-001",
            "from_agent": "growth-campaign-planner-agent",
            "to_agent": "growth-data-feasibility-agent",
            "task_type": "feasibility_check",
            "input_refs": {
                "region": "North America",
                "country": "United States",
                "product_line": "PL1",
                "product_model": "MODEL-001",
            },
            "expected_output": "可推广性、库存/交付风险、客户画像、ROI 预估",
            "risk_level": "R2",
            "review_required": True,
            "writeback_plan": {
                "target_table": "mvp1_feasibility_checks",
                "operation": "upsert",
            },
        },
        ensure_ascii=False,
        indent=2,
    )
    scope_rules = "\n".join(f"- {rule}" for rule in [*AGENT_BOUNDARY_RULES, *AGENT_FORBIDDEN_ACTIONS])
    table_rows = "\n".join(f"| `{table}` | `{config['pk']}` | {config['description']} |" for table, config in TABLES.items())
    return {
        "mvp1-scope-rules.md": clean(f"""
            # MVP-1 范围规则

            {scope_rules}
        """),
        "session-send-protocol.md": clean(f"""
            # session send 协作协议

            MVP-1 跨 Agent 消息统一使用 `session send`。消息必须包含 `campaign_id`、`from_agent`、`to_agent`、`task_type`、`input_refs`、`expected_output`、`risk_level`、`review_required`、`writeback_plan`。

            ## 下发消息示例

            ```json
            {session_payload}
            ```

            ## 回传要求

            回传必须包含 `campaign_id`、`owner_agent`、`status`、`summary`、`output_refs`、`risk_level`、`review_required`、`writeback_plan` 和 `next_agent_message`。禁止直接传递客户明细、平台账号凭据或外部系统写回凭据。
        """),
        "local-gdp-schema.md": clean(f"""
            # 本地 GDP Schema

            SQLite 文件：`data/gdp.sqlite`。

            | 表名 | 主键 | 用途 |
            | --- | --- | --- |
            {table_rows}

            `records` 以 SQLite 表为准。所有自动生成结论默认 `review_status=draft` 或 `pending_review`，不得直接成为正式外发内容。
        """),
        "id-rules.md": clean("""
            # ID 规则

            | 对象 | 格式 |
            | --- | --- |
            | Campaign_ID | `CMP-YYYY-REGION-PRODUCT-NNN` |
            | Content_ID | `CNT-YYYY-PLATFORM-ASSET-NNN` |
            | Pack_ID | `PACK-YYYY-CAMPAIGN-NNN` |
            | UTM_ID | `UTM-YYYY-CAMPAIGN-NNN` |
            | Review_ID | `REV-YYYYMMDD-NNN` |
            | Run_ID | `RUN-YYYYMMDDHHMMSS-AGENT-SKILL` |

            缺少主键的输入不得自动写入 GDP，必须先输出补充字段请求。
        """),
        "output-templates.md": clean("""
            # 输出模板

            ## Markdown 摘要

            - Campaign_ID：
            - 主责 Agent：
            - 输入目标：
            - 区域/国家/平台：
            - 产品线/型号/场景：
            - 风险等级：
            - 审核状态：
            - 证据引用：
            - 下一步：

            ## 结构化 JSON

            ```json
            {
              "campaign_id": "CMP-YYYY-REGION-PRODUCT-NNN",
              "owner_agent": "",
              "risk_level": "R1|R2|R3|R4",
              "review_required": true,
              "source_refs": [],
              "outputs": {},
              "writeback_plan": [],
              "next_agent_message": null
            }
            ```
        """),
        "campaign-brief-template.md": clean("""
            # Campaign Brief 模板

            - Campaign_ID：
            - 企业增长目标：
            - 目标区域/国家：
            - 产品线/型号：
            - 目标客户画像：
            - 应用场景：
            - 预算/周期：
            - 目标线索/RFQ：
            - 推荐平台：
            - 内容主题：
            - 风险等级：
            - 审核状态：
        """),
        "content-requirement-template.md": clean("""
            # 内容要求单模板

            | 字段 | 要求 |
            | --- | --- |
            | Campaign_ID | 必填 |
            | Asset_Type | 社媒、文章、视频、图片、广告标题、邮件草稿 |
            | Platform | LinkedIn、YouTube、Reddit、Google、行业媒体等 |
            | Language | en-US、es、fr 等 |
            | Scenario | 应用场景 |
            | CTA | 表单、下载资料、预约演示、联系渠道商 |
            | Review_Required | true/false |
        """),
        "content-asset-package-template.md": clean("""
            # 内容资产包模板

            - Campaign_ID：
            - Content_ID：
            - Asset_Type：
            - Platform：
            - Language：
            - Title：
            - Body_Ref：
            - Facts_Ref：
            - Risk_Level：
            - Version：
            - Review_Status：
            - 禁用表达检查：
            - 产品事实审核点：
        """),
        "platform-promotion-pack-template.md": clean("""
            # 平台发布包模板

            | Platform | Content_ID | Title | Format | Publish_Window | CTA | UTM | Checklist |
            | --- | --- | --- | --- | --- | --- | --- | --- |

            发布包仅供人工审核和执行，不自动调用平台发布 API。
        """),
        "human-review-checklist.md": clean("""
            # 人工审核清单

            - [ ] Campaign 目标、预算、周期、区域、国家完整。
            - [ ] 产品型号、参数、认证、兼容性事实来源可追溯。
            - [ ] 库存、供应链、区域可售性、可交付性已确认。
            - [ ] 客户画像只保留分层摘要，不包含客户明细。
            - [ ] ROI 假设、转化率和毛利口径已标注。
            - [ ] 内容无夸大承诺、禁用表达、版权风险。
            - [ ] Content_ID、Campaign_ID、UTM 完整。
            - [ ] 发布包为人工执行清单，未自动发布。
        """),
        "cron-runbook.md": clean("""
            # Cron 运行手册

            Cron 只做短触发，不承载长规则。具体业务规则在对应 `skills/*/SKILL.md` 和 references 中。

            - `weekly-campaign-planning`：每周一 09:00。
            - `weekly-feasibility-refresh`：每周一 10:30。
            - `weekly-content-generation`：每周二 09:00。
            - `weekly-promotion-pack`：每周三 09:00。
            - `friday-mvp1-review`：每周五 16:00。
        """),
    }


def acceptance_sample() -> str:
    return clean("""
        # MVP-1 验收样例

        ## 输入

        未来 30 天在北美市场推广产品线 PL1 的 MODEL-001，目标是获取 B2B 安装商和渠道商线索，预算 50000，重点平台 LinkedIn、YouTube、Reddit。

        ## Campaign Brief

        - Campaign_ID：`CMP-2026-NA-PL1-001`
        - 增长目标：30 天内获取北美 B2B 安装商和渠道商线索。
        - 产品线/型号：PL1 / MODEL-001。
        - 预算：50000。
        - 审核状态：pending_review。

        ## 区域、国家、平台选择理由

        - 区域：North America。
        - 国家：United States 优先，Canada 次优。
        - 平台：LinkedIn 用于 B2B 决策人触达，YouTube 用于视频说明和安装场景，Reddit 用于行业社区讨论与反馈收集。

        ## 产品型号和应用场景选择理由

        - MODEL-001 与 PL1 主推场景匹配。
        - 应用场景：B2B 安装、渠道商方案展示、安装调试教育内容。
        - 产品参数和认证信息进入 R3 审核。

        ## 供应链/库存/可交付性校验结果

        - 库存状态：待供应链确认，暂定 `pending_review`。
        - 区域可售性：需要确认北美认证材料。
        - 可交付性：如交期超过 Campaign 周期，标记阻断项。

        ## 客户画像和客户分层

        - Segment A：B2B installer，关注安装效率、兼容性、售后支持。
        - Segment B：channel distributor，关注利润空间、培训材料、交付稳定性。
        - 不导出客户明细，不主动触达。

        ## ROI 预估

        - 预算：50000。
        - 预计线索：180。
        - 预计 RFQ：36。
        - 预计订单：8。
        - ROI：1.6，待财务/销售口径审核。

        ## 内容要求单

        | Asset_Type | Platform | Language | CTA | Review_Required |
        | --- | --- | --- | --- | --- |
        | social_copy | LinkedIn | en-US | Book a demo | true |
        | video_script | YouTube | en-US | Watch installation guide | true |
        | discussion_prompt | Reddit | en-US | Share installation questions | true |

        ## 内容资产草稿

        ### 社媒文案

        LinkedIn 草稿聚焦安装商痛点、渠道利润和 MODEL-001 的可审核产品事实。所有参数等待产品事实审核。

        ### 文章草稿

        标题：How B2B installers can evaluate PL1 MODEL-001 for North America projects。
        大纲覆盖应用场景、兼容性、安装准备、渠道支持和 FAQ。

        ### 视频脚本

        60-90 秒 YouTube 脚本：问题场景、MODEL-001 方案定位、安装流程、审核提示和 CTA。

        ## 平台适配版本

        - LinkedIn：短文案 + 行业标签 + demo CTA。
        - YouTube：标题、简介、章节、封面要求、90 秒脚本。
        - Reddit：讨论帖问题式标题，避免硬广和未经审核参数。

        ## 内容日历

        | Day | Platform | Content_ID | Action |
        | --- | --- | --- | --- |
        | D1 | LinkedIn | CNT-2026-LI-SOC-001 | 发布社媒草稿，人工审核后执行 |
        | D3 | YouTube | CNT-2026-YT-VID-001 | 上传视频脚本对应素材，人工审核后执行 |
        | D5 | Reddit | CNT-2026-RD-DIS-001 | 发布讨论帖，人工审核后执行 |

        ## UTM 和 Content_ID 表

        | Content_ID | UTM |
        | --- | --- |
        | CNT-2026-LI-SOC-001 | `utm_source=linkedin&utm_medium=social&utm_campaign=CMP-2026-NA-PL1-001` |
        | CNT-2026-YT-VID-001 | `utm_source=youtube&utm_medium=video&utm_campaign=CMP-2026-NA-PL1-001` |
        | CNT-2026-RD-DIS-001 | `utm_source=reddit&utm_medium=community&utm_campaign=CMP-2026-NA-PL1-001` |

        ## 发布前审核清单

        - [ ] 产品参数、认证、兼容性事实来源已确认。
        - [ ] 库存、供应链、可交付性结论已确认。
        - [ ] ROI 假设已由业务负责人确认。
        - [ ] 内容无未经审核承诺。
        - [ ] 发布包只供人工执行，未自动发布。

        ## session send

        `growth-campaign-planner-agent -> growth-data-feasibility-agent -> content-asset-agent -> channel-promotion-pack-agent -> growth-campaign-planner-agent`

        ## GDP 写入记录

        初始化脚本会将样例写入 `data/gdp.sqlite` 的 `mvp1_campaigns`、`mvp1_feasibility_checks`、`mvp1_roi_estimates`、`mvp1_content_assets`、`mvp1_promotion_packs`、`mvp1_utm_links`、`mvp1_reviews` 和 `mvp1_agent_runs`。所有记录保持 `draft` 或 `pending_review`，不自动发布、不发送邮件、不写 CRM/ERP。
    """)


def inbox_readme(agent: dict[str, object] | None = None) -> str:
    name = "MVP-1 root" if agent is None else str(agent["name"])
    return clean(f"""
        # {name} inbox

        放置人工录入、源系统摘要、上游 Agent 输出或验收样例输入。格式建议使用 JSONL，每行一条记录，必须包含 `source_ref`、`campaign_id` 和 `review_status`。
    """)


def outbox_readme(agent: dict[str, object] | None = None) -> str:
    name = "MVP-1 root" if agent is None else str(agent["name"])
    return clean(f"""
        # {name} outbox

        保存待审核输出、`session send` payload、`writeback_plan` 和发布包索引。这里的内容不代表已发布或已写入外部系统。
    """)


def exports_readme() -> str:
    return clean("""
        # exports

        放置人工审核通过后导出的 Campaign 发布包、内容日历、UTM 表或平台执行清单。MVP-1 不自动发布导出文件。
    """)


def build() -> None:
    all_jobs = build_jobs()

    write_text(ROOT / "README.md", root_readme())
    write_text(ROOT / "project.md", project_md())
    write_text(ROOT / "DELIVERY_CHECKLIST.md", delivery_checklist())
    write_text(ROOT / "MVP1_ACCEPTANCE_SAMPLE.md", acceptance_sample())
    write_json(ROOT / "package-manifest.json", package_manifest(all_jobs))
    write_json(ROOT / "jobs.json", {"version": 1, "jobs": all_jobs})
    write_text(ROOT / "data" / "schema.sql", schema_sql())
    write_json(ROOT / "data" / "schema.json", schema_json())
    write_text(ROOT / "data" / "inbox" / "README.md", inbox_readme())
    write_text(ROOT / "data" / "outbox" / "README.md", outbox_readme())
    write_text(ROOT / "data" / "exports" / "README.md", exports_readme())

    for filename, content in reference_texts().items():
        write_text(ROOT / "references" / filename, content)

    for agent in AGENTS:
        workspace = ROOT / str(agent["workspace"])
        agent_jobs = [job for job in all_jobs if job["agent"]["id"] == agent["agent_id"]]
        write_text(workspace / "AGENTS.md", agents_md(agent))
        write_text(workspace / "IDENTITY.md", identity_md(agent))
        write_text(workspace / "MEMORY.md", memory_md(agent))
        write_text(workspace / "TOOLS.md", tools_md(agent))
        write_text(workspace / "HEARTBEAT.md", heartbeat_md(agent))
        write_json(workspace / "skill-manifest.json", skill_manifest(agent, agent_jobs))
        write_json(workspace / "jobs.json", {"version": 1, "jobs": agent_jobs})
        write_json(workspace / "data" / "catalog.json", workspace_catalog(agent))
        write_text(workspace / "data" / "inbox" / "README.md", inbox_readme(agent))
        write_text(workspace / "data" / "outbox" / "README.md", outbox_readme(agent))
        for skill_name, description in agent["skills"].items():
            write_text(workspace / "skills" / skill_name / "SKILL.md", skill_md(agent, skill_name, description))
        for job in agent_jobs:
            write_json(workspace / "cron" / f"{job['name']}.json", job)


if __name__ == "__main__":
    build()
    print("generated brand promotion mvp1 package")

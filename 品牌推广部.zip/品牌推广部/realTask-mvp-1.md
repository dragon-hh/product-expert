# 品牌发展部 AI 作战团队 MVP-1 真实需求

## 1. MVP-1 判断

MVP-1 建议只做两大业务流：

1. 增长战役规划流
2. 内容生产与推广流

对应原始主流程中的这一段：

```text
企业增长目标
-> 区域与国家选择
-> 平台渠道库调用
-> 产品线与产品型号选择
-> 供应链/库存/可交付性校验
-> 客户画像与客户清单选择
-> 应用场景选择
-> 财务利润与 ROI 预估
-> 内容要求选择
-> AI 生成内容资产
-> 内容推广 AI 全球平台推广
```

这个阶段的目标不是完整 L5，不做客户消息自动处理，也不做销售、交付、运维、商城、积分、ERP/CRM 自动写回。MVP-1 的目标是：输入一个企业增长目标，产出一套可审核、可发布、可追踪的全球内容推广战役包。

MVP-1 选择“增长战役规划 + 内容生产与推广”的原因：

- 它处在整条增长链路的最前端，不依赖客户邮件、CRM 写回、ERP 改单、售后工单等高风险系统。
- 输出物明确：Campaign brief、区域平台策略、产品/客户/场景选择、ROI 预估、内容草稿、平台发布包。
- 能展示 AI 的直接价值：从目标到内容推广包的生成效率提升。
- 风险边界可控：所有内容先生成草稿和发布清单，不自动对外发布。
- 后续可以自然接到 MVP-2：询盘/RFQ/订单信号采集与客户经理 AI 分流。


## 4. MVP-1 业务流程

```text
1. 输入企业增长目标
2. 选择区域与国家
3. 调用平台渠道库
4. 选择产品线与产品型号
5. 校验供应链、库存、可交付性
6. 选择客户画像与客户清单
7. 选择应用场景
8. 预估财务利润与 ROI
9. 定义内容要求
10. 生成内容资产
11. 适配全球平台推广
12. 输出可审核的 Campaign 发布包
```

## 5. MVP-1 建议使用 4 个 OpenClaw agent

### 5.1 `growth-campaign-planner-agent`

定位：增长战役规划 Agent。

负责业务动作：

- 接收企业增长目标。
- 选择区域、国家和优先级。
- 调用平台渠道库，选择适合的推广平台。
- 选择产品线、产品型号和应用场景。
- 定义内容要求和 Campaign brief。
- 拆解任务给其他 agent。

主要输入：

- 企业增长目标。
- 目标区域或国家。
- 产品线候选。
- 平台渠道库。
- 历史 Campaign 表现。
- 预算、周期、目标线索数或 RFQ 目标。

处理过程：

1. 判断目标属于品牌曝光、线索获取、RFQ 拉动、渠道拓展还是新品推广。
2. 根据目标选择区域、国家和优先平台。
3. 形成 Campaign brief。
4. 通过 `session send` 请求 `growth-data-feasibility-agent` 做数据与可行性校验。
5. 校验通过后把内容要求发送给 `content-asset-agent`。

主要输出：

- `Campaign Brief`
- 区域/国家/平台推荐
- 产品线/型号候选
- 应用场景候选
- 内容要求单
- 任务拆解清单

### 5.2 `growth-data-feasibility-agent`

定位：数据与可行性校验 Agent。

负责业务动作：

- 校验产品是否适合在目标区域推广。
- 校验库存、供应链、可交付性。
- 选择客户画像与客户清单。
- 预估财务利润和 ROI。
- 标记不可推广、需人工确认或高风险事项。

主要输入：

- Campaign brief。
- Product_Line、Product_Model。
- Region、Country。
- 客户画像。
- 客户清单。
- 库存/供应链/可交付性数据。
- 成本、毛利、预算、预估转化率。

处理过程：

1. 检查产品型号是否有足够事实资料、认证资料和内容素材。
2. 检查目标区域是否可售、可交付。
3. 检查客户画像和客户清单是否可用。
4. 计算基础 ROI 预估。
5. 给出推广可行性结论。

主要输出：

- 可推广产品清单。
- 不可推广或需人工确认项。
- 目标客户画像和客户清单摘要。
- ROI 预估。
- 数据缺口清单。
- 风险和审核要求。

### 5.3 `content-asset-agent`

定位：内容资产生成 Agent。

负责业务动作：

- 根据 Campaign brief 生成内容资产草稿。
- 生成社媒文案、文章大纲、视频脚本、图片提示词、广告标题、CTA。
- 生成多语言版本或本地化初稿。
- 给内容附带事实依据、适用区域和审核状态。

主要输入：

- Campaign brief。
- 产品事实资料。
- 目标客户画像。
- 应用场景。
- 平台要求。
- 语言要求。
- 品牌语气和禁用表达。

处理过程：

1. 拆分内容资产类型。
2. 为不同平台生成不同内容版本。
3. 标注产品事实、认证、兼容性、安装调试等需要审核的点。
4. 调用内容风险审核 skill。
5. 生成内容资产包。

主要输出：

- 社媒文案。
- SEO/行业文章草稿。
- 视频脚本和分镜建议。
- 图片生成提示词。
- 广告标题和 CTA。
- 邮件草稿可选，但 MVP-1 不自动发送。
- 内容事实依据和审核清单。

### 5.4 `channel-promotion-pack-agent`

定位：渠道推广编排 Agent。

负责业务动作：

- 将内容资产适配到目标平台。
- 生成平台发布格式、内容日历、UTM、发布时间建议。
- 输出人工可执行的发布包。
- 设计后续信号采集字段，但不在 MVP-1 自动处理询盘/RFQ。

主要输入：

- 内容资产包。
- 平台渠道库。
- Region、Country、Language。
- Campaign_ID、Content_ID。
- 平台规则和格式要求。

处理过程：

1. 根据平台要求调整字数、标题、标签、CTA、封面要求和视频时长建议。
2. 为每条内容生成 Content_ID 和 UTM。
3. 生成发布日历和平台执行清单。
4. 输出待人工审核/发布的推广包。

主要输出：

- 平台发布包。
- 内容日历。
- UTM 规则。
- Content_ID 列表。
- 平台字段表。
- 后续采集字段建议。

## 6. 4 个 agent 的协作链路

```text
growth-campaign-planner-agent
  -> growth-data-feasibility-agent
  -> content-asset-agent
  -> channel-promotion-pack-agent
  -> growth-campaign-planner-agent 汇总
```

跨 agent 消息统一使用 `session send`，消息必须包含：

- `campaign_id`
- `from_agent`
- `to_agent`
- `task_type`
- `input_refs`
- `expected_output`
- `risk_level`
- `review_required`
- `writeback_plan`

示例：

```json
{
  "campaign_id": "CMP-2026-NA-PL1-001",
  "from_agent": "growth-campaign-planner-agent",
  "to_agent": "growth-data-feasibility-agent",
  "task_type": "feasibility_check",
  "input_refs": {
    "region": "North America",
    "country": "United States",
    "product_line": "PL1",
    "product_model": "MODEL-001"
  },
  "expected_output": "可推广性、库存/交付风险、客户画像、ROI 预估",
  "risk_level": "R2",
  "review_required": true,
  "writeback_plan": {
    "target_table": "mvp1_feasibility_checks",
    "operation": "upsert"
  }
}
```

## 7. MVP-1 skills 清单

### 7.1 `growth-campaign-planner-agent` skills

| skill | 功能 | 输出 |
|---|---|---|
| `campaign-brief-skill` | 根据增长目标生成 Campaign brief | Campaign brief |
| `region-country-prioritize-skill` | 选择区域、国家和优先级 | 区域/国家推荐 |
| `platform-channel-select-skill` | 从平台渠道库选择平台 | 平台组合 |
| `product-scenario-select-skill` | 选择产品线、型号和应用场景 | 产品/场景候选 |
| `content-requirement-skill` | 定义内容资产类型、语言、平台格式和 CTA | 内容需求单 |

### 7.2 `growth-data-feasibility-agent` skills

| skill | 功能 | 输出 |
|---|---|---|
| `product-fact-check-skill` | 校验产品型号、参数、认证、兼容性资料是否完整 | 产品事实校验 |
| `availability-check-skill` | 校验库存、供应链、区域可售性、可交付性 | 可推广结论 |
| `customer-profile-select-skill` | 选择客户画像和客户清单 | 客户画像摘要 |
| `roi-estimate-skill` | 预估成本、毛利、线索/RFQ/订单贡献 | ROI 预估 |
| `feasibility-risk-flag-skill` | 标记数据缺口、不可推广项、需人工确认项 | 风险清单 |

### 7.3 `content-asset-agent` skills

| skill | 功能 | 输出 |
|---|---|---|
| `social-copy-draft-skill` | 生成社媒文案 | 平台文案草稿 |
| `article-draft-skill` | 生成 SEO/行业文章草稿 | 文章草稿 |
| `video-script-skill` | 生成营销视频、安装视频、调试视频、培训视频脚本 | 视频脚本 |
| `image-prompt-skill` | 生成图片设计 brief 或 AI 图片提示词 | 图片提示词/设计需求 |
| `localized-content-skill` | 生成多语言或区域本地化初稿 | 本地化内容 |
| `content-risk-review-skill` | 检查产品事实、版权、禁用表达、R3/R4 风险 | 审核清单 |

### 7.4 `channel-promotion-pack-agent` skills

| skill | 功能 | 输出 |
|---|---|---|
| `platform-format-adapt-skill` | 根据平台格式适配内容 | 平台版本 |
| `content-calendar-skill` | 生成内容日历和发布时间建议 | 内容日历 |
| `utm-generate-skill` | 生成 UTM、Content_ID、Campaign_ID 映射 | UTM 表 |
| `publishing-checklist-skill` | 生成发布前检查清单 | 发布检查表 |
| `promotion-pack-export-skill` | 汇总所有平台内容和执行清单 | 推广发布包 |

## 8. MVP-1 cron 定时任务

cron 只做短触发，不承载长规则。

| cron | 频率 | agent | 任务 |
|---|---|---|---|
| `weekly-campaign-planning` | 每周一 09:00 | `growth-campaign-planner-agent` | 生成本周 Campaign brief 草案 |
| `weekly-feasibility-refresh` | 每周一 10:30 | `growth-data-feasibility-agent` | 刷新产品可推广性、客户画像和 ROI 预估 |
| `weekly-content-generation` | 每周二 09:00 | `content-asset-agent` | 根据已通过 brief 生成内容资产草稿 |
| `weekly-promotion-pack` | 每周三 09:00 | `channel-promotion-pack-agent` | 生成平台发布包、内容日历和 UTM 表 |
| `friday-mvp1-review` | 每周五 16:00 | `growth-campaign-planner-agent` | 汇总本周 Campaign 包、缺口和待审核项 |

## 9. MVP-1 本地 GDP

建议 MVP-1 单独建立轻量本地 GDP，可后续并入完整 GDP。

文件建议：

- `data/gdp.sqlite`
- `data/inbox/*.jsonl`
- `data/outbox/*.jsonl`
- `data/exports/`

### 9.1 核心表

| 表名 | 主键 | 关键字段 | 来源 | 写回规则 | 审核状态 |
|---|---|---|---|---|---|
| `mvp1_campaigns` | `campaign_id` | `goal`, `region`, `country`, `product_line`, `product_model`, `scenario`, `owner`, `status` | Campaign brief | 本地 upsert | `draft/pending_review/approved/rejected` |
| `mvp1_platform_channels` | `channel_id` | `region`, `country`, `platform`, `account_ref`, `content_format`, `cta_rule`, `risk_note` | 平台渠道库 | 人工维护或导入 | `approved/pending_review` |
| `mvp1_products` | `product_model` | `product_line`, `facts_ref`, `certifications`, `compatibility`, `available_regions`, `risk_note` | 产品资料/PLM 摘要 | 不直接写 PLM | `pending_review/approved` |
| `mvp1_feasibility_checks` | `check_id` | `campaign_id`, `product_model`, `inventory_status`, `deliverability_status`, `customer_profile_status`, `roi_status`, `blocking_reason` | 数据校验 agent | 本地追加 | `pending_review/approved/blocked` |
| `mvp1_customer_profiles` | `profile_id` | `region`, `country`, `segment`, `industry`, `pain_points`, `buyer_role`, `language` | 客户画像/客户清单摘要 | 不导出客户明细 | `pending_review/approved` |
| `mvp1_roi_estimates` | `roi_id` | `campaign_id`, `budget`, `estimated_margin`, `estimated_leads`, `estimated_rfq`, `estimated_orders`, `roi` | ROI skill | 本地追加 | `draft/pending_review/approved` |
| `mvp1_content_requirements` | `requirement_id` | `campaign_id`, `asset_type`, `platform`, `language`, `scenario`, `cta`, `content_angle`, `review_required` | 规划 agent | 本地 upsert | `draft/approved` |
| `mvp1_content_assets` | `content_id` | `campaign_id`, `asset_type`, `platform`, `language`, `title`, `body_ref`, `facts_ref`, `risk_level`, `version` | 内容生成 agent | 只生成草稿 | `draft/pending_review/approved/rejected` |
| `mvp1_promotion_packs` | `pack_id` | `campaign_id`, `platform`, `content_ids`, `publish_window`, `utm_ref`, `checklist_ref` | 渠道推广 agent | 人工发布前审核 | `draft/pending_review/approved` |
| `mvp1_utm_links` | `utm_id` | `campaign_id`, `content_id`, `utm_source`, `utm_medium`, `utm_campaign`, `landing_page` | UTM skill | 本地生成 | `draft/approved` |
| `mvp1_reviews` | `review_id` | `entity_type`, `entity_id`, `review_type`, `risk_level`, `conclusion`, `reviewer`, `evidence_ref` | 审核 skill/人工审核 | 只追加 | `approved/rejected/needs_human` |
| `mvp1_agent_runs` | `run_id` | `agent_id`, `skill_id`, `campaign_id`, `input_hash`, `output_ref`, `status`, `cost`, `latency_ms` | OpenClaw 运行日志 | 只追加 | `synced/failed` |

## 10. MVP-1 MEMORY.md 应沉淀的规则

每个 agent 都有自己的 `MEMORY.md`，但 MVP-1 需要共享这些长期规则：

- MVP-1 只做增长战役规划和内容生产推广，不处理客户消息闭环。
- 内容可以生成草稿和发布包，但不能自动发布。
- 邮件内容可以生成草稿，但不能自动发送。
- 产品参数、认证、兼容性、安装调试、故障排查内容必须进入审核。
- 产品可推广性必须经过库存、供应链、区域可售性、可交付性和 ROI 检查。
- 客户清单在 MVP-1 只做画像和分层，不导出明细，不做主动触达。
- 所有 Campaign 输出必须有 `Campaign_ID`、`Content_ID`、UTM 和审核状态。
- 所有内容资产必须标注适用平台、语言、区域、产品型号、版本和事实来源。

## 11. MVP-1 交付物

MVP-1 应交付：

- 4 个 OpenClaw agent 工作区。
- 每个 agent 的 `AGENTS.md`、`MEMORY.md`、`skills/`、`cron/`、`data/inbox/`、`data/outbox/`。
- 20 个左右核心 skill。
- 5 个 cron 定时任务。
- 本地 GDP schema 和初始化脚本。
- `session send` 协作协议。
- Campaign brief 模板。
- 内容要求单模板。
- 内容资产包模板。
- 平台发布包模板。
- 人工审核清单。
- MVP-1 验收样例。

## 12. MVP-1 验收标准

用一个真实或模拟的企业增长目标做端到端验收：

输入示例：

```text
未来 30 天在北美市场推广产品线 PL1 的 MODEL-001，目标是获取 B2B 安装商和渠道商线索，预算 50000，重点平台 LinkedIn、YouTube、Reddit。
```

系统应输出：

- Campaign brief。
- 区域、国家、平台选择理由。
- 产品型号和应用场景选择理由。
- 供应链/库存/可交付性校验结果。
- 客户画像和客户分层。
- ROI 预估。
- 内容要求单。
- 至少 3 类内容资产草稿：社媒文案、文章草稿、视频脚本或图片提示词。
- 平台适配版本。
- 内容日历。
- UTM 和 Content_ID 表。
- 发布前审核清单。
- 所有结果写入本地 GDP。

通过标准：

- 能从一个增长目标生成完整 Campaign 发布包。
- 内容不自动发布，只输出人工可审核发布包。
- 不触发客户邮件、私信、CRM/ERP 写操作。
- 产品事实和高风险内容有审核标记。
- GDP 表中能查到 Campaign、内容资产、ROI、审核和运行记录。
- 4 个 agent 之间能通过 `session send` 完成任务交接。

## 13. MVP-1 之后的 MVP-2 建议

MVP-1 完成后，MVP-2 再做：

```text
询盘/RFQ/订单信号采集
-> 客户经理 AI 识别与分流
-> 邮件营销 AI 事件触发培育
```

也就是把 MVP-1 的推广包后续效果接住，开始处理客户互动和线索分流。这样比一开始就做完整客户消息自动化更稳。

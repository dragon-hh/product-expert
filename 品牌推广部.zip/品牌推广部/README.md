# 品牌发展部 AI 作战团队 MVP-1 OpenClaw 交付包

本目录按 `realTask-mvp-1.md` 交付 MVP-1：增长战役规划流 + 内容生产与推广流。目标是从一个企业增长目标产出可审核、可发布、可追踪的全球内容推广战役包。

## MVP-1 边界

- 做：Campaign brief、区域/国家/平台策略、产品/客户/场景选择、ROI 预估、内容草稿、平台发布包。
- 不做：客户消息自动处理、销售闭环、交付、运维、商城、积分、CRM/ERP 自动写回。
- 所有内容先生成草稿和发布清单，人工审核后再发布。

## 工作区

| Agent | 工作区 | 主责 |
| --- | --- | --- |
| `growth-campaign-planner-agent` | `workspace-growth-campaign-planner` | 从企业增长目标形成 Campaign brief、区域/国家/平台推荐、产品/场景候选、内容需求单，并负责跨 agent 拆解与最终汇总。 |
| `growth-data-feasibility-agent` | `workspace-growth-data-feasibility` | 校验产品事实、认证、库存、供应链、区域可售性、客户画像、客户分层、利润与 ROI，并标记阻断项和待人工确认项。 |
| `content-asset-agent` | `workspace-content-asset` | 根据 Campaign brief 和可行性结果生成社媒文案、文章草稿、视频脚本、图片提示词、本地化内容和内容风险审核清单。 |
| `channel-promotion-pack-agent` | `workspace-channel-promotion-pack` | 将内容资产适配为平台发布格式、内容日历、UTM、Content_ID、发布检查表和人工可执行的 Campaign 发布包。 |

## 入口

- `package-manifest.json`：交付包总索引。
- `jobs.json`：5 个 MVP-1 cron 注册清单。
- `data/schema.sql`：本地 GDP SQLite schema。
- `tools/init_mvp1_gdp.py`：初始化 `data/gdp.sqlite` 并写入验收样例记录。
- `references/session-send-protocol.md`：跨 agent 协作协议。
- `MVP1_ACCEPTANCE_SAMPLE.md`：端到端验收样例。

## 验证

```powershell
python .\tools\init_mvp1_gdp.py
python .\tools\validate_mvp1_brand_promotion_package.py
python -m unittest tests.test_mvp1_package_contract -v
```

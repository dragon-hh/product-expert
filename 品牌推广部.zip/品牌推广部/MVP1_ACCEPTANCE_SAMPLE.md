# MVP-1 验收样例

## 输入

未来 30 天在北美市场推广产品线 PL1 的 MODEL-001，目标是获取 B2B 安装商和渠道商线索，预算 50000，重点平台 LinkedIn、YouTube、Reddit。

## Campaign Brief

- Campaign_ID：`CMP-2026-NA-PL1-001`
- 增长目标：30 天内获取北美 B2B 安装商和渠道商线索。
- 产品线/型号：PL1 / MODEL-001。
- 预算：50000。
- 审核状态：pending_review。

## 区域、国家、平台选择理由

- 区域：North America。
- 国家：United States 优先，Canada 次优。
- 平台：LinkedIn 用于 B2B 决策人触达，YouTube 用于视频说明和安装场景，Reddit 用于行业社区讨论与反馈收集。

## 产品型号和应用场景选择理由

- MODEL-001 与 PL1 主推场景匹配。
- 应用场景：B2B 安装、渠道商方案展示、安装调试教育内容。
- 产品参数和认证信息进入 R3 审核。

## 供应链/库存/可交付性校验结果

- 库存状态：待供应链确认，暂定 `pending_review`。
- 区域可售性：需要确认北美认证材料。
- 可交付性：如交期超过 Campaign 周期，标记阻断项。

## 客户画像和客户分层

- Segment A：B2B installer，关注安装效率、兼容性、售后支持。
- Segment B：channel distributor，关注利润空间、培训材料、交付稳定性。
- 不导出客户明细，不主动触达。

## ROI 预估

- 预算：50000。
- 预计线索：180。
- 预计 RFQ：36。
- 预计订单：8。
- ROI：1.6，待财务/销售口径审核。

## 内容要求单

| Asset_Type | Platform | Language | CTA | Review_Required |
| --- | --- | --- | --- | --- |
| social_copy | LinkedIn | en-US | Book a demo | true |
| video_script | YouTube | en-US | Watch installation guide | true |
| discussion_prompt | Reddit | en-US | Share installation questions | true |

## 内容资产草稿

### 社媒文案

LinkedIn 草稿聚焦安装商痛点、渠道利润和 MODEL-001 的可审核产品事实。所有参数等待产品事实审核。

### 文章草稿

标题：How B2B installers can evaluate PL1 MODEL-001 for North America projects。
大纲覆盖应用场景、兼容性、安装准备、渠道支持和 FAQ。

### 视频脚本

60-90 秒 YouTube 脚本：问题场景、MODEL-001 方案定位、安装流程、审核提示和 CTA。

## 平台适配版本

- LinkedIn：短文案 + 行业标签 + demo CTA。
- YouTube：标题、简介、章节、封面要求、90 秒脚本。
- Reddit：讨论帖问题式标题，避免硬广和未经审核参数。

## 内容日历

| Day | Platform | Content_ID | Action |
| --- | --- | --- | --- |
| D1 | LinkedIn | CNT-2026-LI-SOC-001 | 发布社媒草稿，人工审核后执行 |
| D3 | YouTube | CNT-2026-YT-VID-001 | 上传视频脚本对应素材，人工审核后执行 |
| D5 | Reddit | CNT-2026-RD-DIS-001 | 发布讨论帖，人工审核后执行 |

## UTM 和 Content_ID 表

| Content_ID | UTM |
| --- | --- |
| CNT-2026-LI-SOC-001 | `utm_source=linkedin&utm_medium=social&utm_campaign=CMP-2026-NA-PL1-001` |
| CNT-2026-YT-VID-001 | `utm_source=youtube&utm_medium=video&utm_campaign=CMP-2026-NA-PL1-001` |
| CNT-2026-RD-DIS-001 | `utm_source=reddit&utm_medium=community&utm_campaign=CMP-2026-NA-PL1-001` |

## 发布前审核清单

- [ ] 产品参数、认证、兼容性事实来源已确认。
- [ ] 库存、供应链、可交付性结论已确认。
- [ ] ROI 假设已由业务负责人确认。
- [ ] 内容无未经审核承诺。
- [ ] 发布包只供人工执行，未自动发布。

## session send

`growth-campaign-planner-agent -> growth-data-feasibility-agent -> content-asset-agent -> channel-promotion-pack-agent -> growth-campaign-planner-agent`

## GDP 写入记录

初始化脚本会将样例写入 `data/gdp.sqlite` 的 `mvp1_campaigns`、`mvp1_feasibility_checks`、`mvp1_roi_estimates`、`mvp1_content_assets`、`mvp1_promotion_packs`、`mvp1_utm_links`、`mvp1_reviews` 和 `mvp1_agent_runs`。所有记录保持 `draft` 或 `pending_review`，不自动发布、不发送邮件、不写 CRM/ERP。

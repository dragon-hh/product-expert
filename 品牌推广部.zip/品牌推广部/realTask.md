# 品牌发展部 AI 作战团队 OpenClaw 工作流包真实需求

来源文件：

- `品牌发展部AI作战团队建设标准方案_v2.0.0_L5企业级AI-native经营操作系统版.docx`
- `品牌发展部AI作战体系_v2.0.0_L5工程级执行工具包.xlsx`

生成目标：把原始 L5 企业级 AI-native 经营操作系统方案，收敛成一套可落地的 OpenClaw agent 工作流包需求。最终交付不是完整平台 UI，也不是照搬 88 个 Agent 岗位，而是可运行的 OpenClaw 工作区、skills、cron、MEMORY.md 和本地 GDP 数据库。

## 0. 需求清晰度诊断

结论：原始 DOCX 和 XLSX 不是一份清晰的客户需求说明书，而是一份“品牌发展部 AI 能力蓝图 + 组织架构 + 治理框架 + 执行模板”。它列了很多可能能力，但没有说清客户当前最想先解决哪一个具体业务问题。因此，如果直接按原文档生成完整 OpenClaw 包，会变成“假大空”的架构包，而不是客户能马上使用的工作流。

### 0.1 原文档能确认的事情

原文档明确覆盖了这些方向：

- 内容推广：文章、社媒文案、图片、营销视频、安装视频、调试视频、客户培训视频。
- 平台推广：LinkedIn、YouTube、TikTok、Facebook、Instagram、Reddit、行业论坛、WhatsApp、WeChat、Douyin、小红书、Bilibili、知乎等平台被列为可选渠道。
- 线索采集：采集询盘、RFQ、订单信号、UTM、Content_ID、Campaign_ID。
- 客户互动：处理评论、私信、表单、邮件、商城、工单等互动。
- 邮件营销：根据关注账号、点击链接、下载资料、报名 Webinar、观看视频、浏览商城、加购、提交 RFQ、退订、投诉等事件触发邮件动作。
- 客户分流：把客户问题分给方案、交付、运维、赋能、销售或人工法务/客服。
- 风险治理：R1-R4、人工审核、禁区动作、Gate、测试包、运行监控、事故 CAPA。
- 数据沉淀：客户状态机、Social Inbox 字段、内容推广采集字段、ROI、审计日志、知识库和 MEMORY 候选。

### 0.2 原文档没有说清的关键问题

这些问题不清楚，就无法判断客户到底要的是“内容生成工具”“社媒监控工具”“邮件自动化工具”还是“客户线索处理工作流”：

- 目标客户是谁：没有指定具体业务部门、使用人、客户经理、运营人员、市场人员还是管理层。
- 具体品牌和产品是什么：只说 3 条产品线，没有产品线名称、SKU、型号、参数库、认证材料和禁用话术。
- 首个落地场景是什么：没有说先做文案/视频/图片生成，还是先做社媒监听，还是先做邮件处理，还是先做 RFQ 分流。
- 要监控哪些平台：列了很多平台，但没有指定本期接入 LinkedIn、YouTube、TikTok、WhatsApp、微信、抖音、小红书、B 站、知乎中的哪几个。
- 要监控谁：没有指定是监控公司官方账号、竞品账号、KOL、客户账号、行业论坛，还是某个员工/客户经理的社交媒体。
- 要监控什么关键词：没有关键词列表、产品词、品牌词、竞品词、故障词、采购意图词、投诉词和地区语言。
- 监控频率和触发方式不清：没有说明实时监听、每天汇总、每周报告，还是只在人工上传数据后处理。
- 内容生成边界不清：没有指定要生成哪些资产类型、每周多少条、哪些语言、是否生成图片成品/视频成品，还是只生成脚本和提示词。
- 发布权限不清：没有说明 AI 是否能直接发布内容，还是只生成草稿等待人工发布。
- 邮件处理范围不清：没有指定接入哪个邮箱、邮件营销系统、CRM 或客户列表，也没有说明是处理收件箱、生成回复草稿，还是主动群发邮件。
- 主动触达权限不清：没有说明是否允许 AI 主动给客户发邮件、私信、WhatsApp、微信消息；如果允许，也没有触达许可、频率和退订机制的实际数据。
- 自动回复边界不清：文档说低风险可自动回复，但没有定义哪些具体话术、哪些客户状态、哪些平台可以自动回复。
- 数据源不清：没有真实 CRM/CDP/ERP/PLM/商城/工单/BI 的接口、导出文件格式、字段样例或账号权限。
- 成功指标不清：没有给出当前基线和目标，比如线索数、RFQ 数、回复时效、内容产量、点击率、转化率、人工节省工时。

### 0.3 当前不能替客户假设的事情

以下内容必须向客户确认，不能从原文档强行推断：

- 客户第一阶段到底要做哪一个 MVP。
- 是否要接入真实社媒账号、邮箱、CRM、ERP、商城或工单系统。
- 是否允许自动发送外部消息。
- 是否允许自动回复客户。
- 是否允许监控个人社交媒体账号。
- 是否监控公开关键词、指定账号、评论区、私信、行业论坛或邮件收件箱。
- 是否要生成图片/视频成品，还是只生成文案、脚本、分镜和图片提示词。
- 哪些平台、地区、语言和产品线是第一阶段范围。

### 0.4 更合理的 MVP 选项

基于原文档，真正可落地的第一阶段应在下面几个方向里选一个，而不是一次做完整 L5：

| MVP 方向 | 客户真实需求表述 | 可交付工作流 |
|---|---|---|
| 内容生成与审核 | 按品牌、产品和平台规则生成文案、视频脚本、图片提示词，用于品牌宣传 | 输入产品/场景/平台/语言 -> 生成内容草稿 -> 风险审核 -> 输出发布包 |
| 社媒/关键词监控 | 监控指定平台、账号或关键词，发现客户问题、采购意向、投诉和竞品信号 | 抓取或导入社媒数据 -> 识别意图/风险 -> 分流 -> 每日报告 |
| 客户邮件处理 | 接入客户邮箱，自动分类邮件、生成回复草稿、识别 RFQ/投诉/售后问题 | 邮件导入 -> 分类 -> 风险分级 -> 回复草稿/转人工/写入 CRM 建议 |
| 主动邮件培育 | 根据客户行为或名单，生成并触发邮件培育，但高风险动作人工确认 | 客户名单/事件 -> 触达许可检查 -> 邮件草稿 -> 审核 -> 发送建议 |
| 询盘/RFQ 分流 | 把表单、邮件、社媒、商城里的询盘/RFQ 统一收口并分给销售/方案/交付 | 统一 inbox -> 客户识别 -> RFQ/意图识别 -> 任务分流 -> GDP 记录 |
| 经营复盘与 ROI | 不先自动化触达，只做数据汇总、内容表现、线索归因和 ROI 复盘 | 导入平台/CRM/订单数据 -> 归因 -> 周报/月报 -> 改进建议 |

建议先让客户在这 6 个 MVP 中选一个。客户没选之前，不应继续生成完整 7-agent 包；最多只能生成“需求澄清清单”和“候选 MVP 方案”。

## 1. 真实业务目标

在原文档没有进一步澄清前，只能把真实业务目标暂定为：品牌发展部希望围绕全球增长建立一组 AI 工作流能力，可能覆盖内容推广、客户互动、询盘/RFQ/订单信号采集、客户经理分流、AI 运营作战部专业处理、风险审核、数据回流、ROI 复盘到知识沉淀。

但这不是可直接开发的客户需求。它缺少首个落地场景、平台范围、账号/关键词范围、数据源、自动化权限、审核人、输入样例和成功指标。后续实现前必须先完成第 0 节的澄清。

原文档的 88 个 Agent 是岗位体系和能力图谱，不适合作为 OpenClaw 初版直接拆成 88 个独立 agent。OpenClaw 版本应把它们合并为少量独立 agent 工作区，每个 agent 有自己的 skill、cron、MEMORY.md、工作目录，并通过 `session send` 传递任务、审核请求、数据写回请求和复盘结论。

## 2. OpenClaw 落地边界

### 2.1 不做什么

- 不做完整平台 UI。
- 不做统一大后台。
- 不把 88 个原始 AI 岗位逐个拆成 88 个 OpenClaw agent。
- 不让 AI 自动执行高风险商业、法务、订单、价格、库存、安装接线、设备参数、退款、合同和赔偿动作。
- 不把 CRM/ERP/PLM/财务/法务等系统写操作直接交给普通业务 agent。

### 2.2 要做什么

- 做一套可运行的 OpenClaw agent 工作流包。
- 每个 agent 独立工作区，独立 `skills/`、`cron/`、`MEMORY.md`、`data/` 或本地缓存。
- 用 `session send` 做跨 agent 协作，而不是共享一个大 prompt。
- 用本地 GDP 作为经营事实和审计证据的本地数据库。
- 所有需要沉淀的业务规则、审核规则、复盘结论先进入候选区，经审核后写入 MEMORY.md。
- 所有外部系统写回先进入 `writeback_queue`，由规则和人工审核决定是否执行。

## 3. 建议的 OpenClaw agent 数量

建议初版保留 7 个 agent 工作区。这样能覆盖原文档七大类能力，又不会把系统拆碎。

| OpenClaw agent | 合并的原始能力 | 主要职责 | 不直接做的事 |
|---|---|---|---|
| `brand-command-agent` | 增长战役编排、任务调度、质量验收、经营复盘 | 接收经营目标，拆解战役任务，调度其他 agent，汇总 ROI 和复盘结论 | 不直接生成大批内容，不绕过审核发布 |
| `content-campaign-agent` | 内容推广、内容工厂、渠道适配、本地化、A/B 测试 | 生成内容草稿、区域平台适配、内容日历、推广采集、UTM 与 Campaign 追踪 | 不发布未经审核内容，不承诺产品事实 |
| `customer-growth-agent` | 客户经理、邮件营销、社区/社群、商城/积分、生命周期 | 统一互动收件箱处理、客户识别、意图判断、风险分级、分流、邮件触发建议 | 不自动报价，不自动处理投诉赔偿 |
| `ops-delivery-agent` | 方案、交付、运维、客户赋能、销售建议、作战路由 | 承接客户经理分流的专业问题，生成方案/交付/运维/赋能/销售跟进草稿 | 不做 R3/R4 直接回复，不承诺交期/认证/折扣 |
| `enterprise-bridge-agent` | PLM、供应链、库存、ERP、财务、法务、客户成功桥接 | 做企业系统只读校验、可交付性判断、产品反馈和经营影响建议 | 不直接改 ERP/订单/库存/价格/合同 |
| `risk-governance-agent` | 风控审核、Gate、测试、上线审批、审计、CAPA | R1-R4 风险判断、硬拦截、发布 Gate、测试集、审计日志、事故响应 | 不替代真人审批，不降低 R3/R4 门槛 |
| `data-roi-memory-agent` | 数据底座、GDP、ROI、数字孪生、知识库更新、Prompt 优化 | 维护本地 GDP，做数据同步、ROI 归因、复盘，管理 MEMORY 候选沉淀 | 不接受无主键、无来源、无审核状态的数据入库 |

## 4. 关键业务功能

### 4.1 增长战役计划与任务调度

业务功能：围绕区域、国家、产品线、客户画像、渠道平台和经营目标生成增长战役计划，并拆解为可执行任务。

使用场景：

- 月度全球增长计划会前，需要为北美、欧洲、南美、非洲、东南亚、亚太生成分区域行动建议。
- 新产品线要进入某个区域，需要先判断平台、内容、客户、供应、合规和 ROI 是否满足启动条件。
- Campaign 执行中出现询盘下降、RFQ 转化偏低、成本过高，需要重新分配任务。

数据输入：

- 区域目标、产品线、产品型号、目标国家、平台渠道库、客户画像、历史内容表现、询盘/RFQ/订单信号、库存与可交付性、ROI 目标。

数据流程：

1. `brand-command-agent` 读取经营目标和历史表现。
2. 通过 `session send` 请求 `content-campaign-agent` 返回平台与内容建议。
3. 请求 `enterprise-bridge-agent` 返回产品可售性、库存、可交付性、毛利或法务风险摘要。
4. 请求 `risk-governance-agent` 返回风险等级和 Gate 要求。
5. 写入本地 GDP 的 campaign、task、review、audit 相关表。

处理过程：

- 识别区域优先级和目标客户群。
- 判断推广产品是否具备内容资产、供应能力和合规边界。
- 拆解任务，设置 Owner、SLA、验收标准、风险等级和写回计划。
- 对 R3/R4 事项标记必须人工审核。

输出：

- Campaign 计划草稿。
- AI 任务分配清单。
- 需要审核的风险事项。
- 需要其他 agent 处理的 `session send` 任务。
- 写入 GDP 的 campaign、task、review 记录。

### 4.2 内容资产生成、区域适配与推广采集

业务功能：生成和管理文章、社媒文案、图片需求、视频脚本、邮件内容、安装/调试/培训内容草稿，并根据区域平台规则做适配。

使用场景：

- 针对某产品线和应用场景生成 LinkedIn、YouTube、TikTok、行业论坛、邮件等渠道内容。
- 针对不同区域改写标题、标签、CTA、语言、本地文化表达和平台格式。
- 从平台推广结果中采集 Inquiry_ID、RFQ_Status、Order_Status、UTM 和内容表现。

数据输入：

- Campaign_ID、Region、Country、Platform、Product_Line、Product_Model、Scenario、CTA、平台规则、语言规则、品牌语气、产品事实库、历史高表现内容。

数据流程：

1. `content-campaign-agent` 接收 Campaign 任务。
2. 调用内容生成、渠道适配、本地化、A/B 变量生成 skill。
3. R2 内容进入轻审核，涉及产品参数、认证、兼容性、安装调试的 R3 内容发送给 `risk-governance-agent`。
4. 发布后采集 UTM、互动、询盘、RFQ、订单信号，写入 GDP。

处理过程：

- 生成内容草稿和多个平台版本。
- 附带事实来源、适用区域、版本、风险等级和审核要求。
- 生成 UTM 字段和推广采集字段。
- 标记不可发布、需产品事实审核或需法务审核的内容。

输出：

- 内容草稿、平台适配稿、视频脚本、邮件草稿。
- UTM 与 Content_ID。
- 内容审核请求。
- 内容表现和商业信号采集记录。

### 4.3 统一互动收件箱、客户识别与分流

业务功能：把社媒评论、私信、表单、邮件、商城、RFQ、工单等客户互动标准化，识别客户身份、意图、风险等级和下一步动作。

使用场景：

- 客户在 YouTube 评论区询问产品参数。
- 潜在客户通过表单提交 RFQ。
- 已有客户在社群里反馈故障码。
- 客户邮件要求报价、折扣、合同条款或投诉赔偿。

数据输入：

- Interaction_ID、Source_Platform、Customer_ID、Social_ID、Email、Country、Language、Product_Line、Product_Model、Interaction_Type、Message_Content。

数据流程：

1. `customer-growth-agent` 执行收件箱标准化。
2. 匹配客户身份和客户生命周期状态。
3. 判断 Intent_Type 和 Risk_Level。
4. 低风险 R1/R2 可生成回复草稿或自动推荐已审核资料。
5. R3/R4 通过 `session send` 发给 `ops-delivery-agent` 或 `risk-governance-agent`。
6. 所有动作写入 interaction、customer、task、audit 表。

处理过程：

- 识别语言、国家、产品线、问题类型、客户阶段。
- 分流到方案、交付、运维、赋能、销售或投诉处理路径。
- 对报价、合同、赔偿、退款、订单修改、高风险安装/调试等动作硬拦截。
- 生成 CRM/CDP 写回建议，不直接修改关键字段。

输出：

- 标准化互动记录。
- 客户状态更新建议。
- 回复草稿或任务分流单。
- 风险审核请求。
- CRM/CDP 同步状态。

### 4.4 邮件营销事件触发与客户培育

业务功能：根据客户事件触发邮件草稿、跟进提醒和多 agent 协同任务。

使用场景：

- 客户关注社媒账号后发送欢迎资料。
- 客户点击产品链接后发送案例和 RFQ 引导。
- 客户下载资料后提醒销售跟进。
- 客户观看安装/调试视频后推荐已审核课程或技术支持入口。
- 客户退订后必须执行退订确认。

数据输入：

- 客户事件、触达许可、退订状态、抑制名单、客户阶段、产品兴趣、邮件模板、区域邮件规则。

数据流程：

1. `customer-growth-agent` 从 interaction、customer、campaign 表识别触发事件。
2. 读取区域邮件触达规则和抑制名单。
3. 生成邮件草稿、跟进提醒或退订确认。
4. 需要方案/交付/运维/赋能信息时，通过 `session send` 请求 `ops-delivery-agent`。
5. 邮件动作和审核状态写入 GDP。

处理过程：

- 判断自动化边界：低风险资料推荐可自动，销售跟进需确认，RFQ 禁止自动报价，投诉必须人工处理。
- 控制触达频率。
- 检查退订和抑制名单。
- 给出邮件发送建议和同步对象。

输出：

- 邮件草稿。
- 销售/客服/专业 agent 跟进提醒。
- 退订确认记录。
- 邮件合规审核记录。

### 4.5 客户生命周期、商城与积分转化

业务功能：推动客户从 Unknown Visitor、Known Lead、Engaged Lead、MQL、SQL、RFQ、Opportunity、Order、Delivery、Installed、Active Customer、Trained、Certified、Repeat 到 Advocate 的状态流转。

使用场景：

- 客户从内容点击进入 MQL。
- 客户提交 RFQ 后进入销售机会。
- 客户下单后进入交付计划。
- 客户完成安装、调试、培训后进入复购或推荐阶段。

数据输入：

- 客户互动、商城行为、订单信号、课程完成、认证状态、积分任务、工单、交付状态、复购行为。

数据流程：

1. `customer-growth-agent` 读取客户事件。
2. 根据状态机规则生成状态变更建议。
3. 需要订单、交付、库存、财务信息时发送给 `enterprise-bridge-agent`。
4. 需要课程/FAQ/赋能内容时发送给 `ops-delivery-agent`。
5. 状态变更写入 GDP，外部 CRM/CDP 只生成写回队列。

处理过程：

- 识别客户阶段和下一步最佳动作。
- 计算意向评分、价值评分、复购潜力。
- 触发商城配件推荐、积分激励、课程路径或销售跟进建议。
- 保留人工确认要求。

输出：

- 客户状态更新建议。
- 下一步动作。
- 复购/配件/课程/认证推荐。
- CRM/CDP 写回计划。

### 4.6 AI 运营作战部专业问题处理

业务功能：承接客户经理 AI 分流后的方案、交付、运维、客户赋能、销售问题，生成可审核的专业草稿和任务。

使用场景：

- 客户问产品型号、参数、认证、兼容性和方案配置。
- 客户问项目启动、交付计划、现场条件和验收资料。
- 客户反馈故障、错误码、维护保养和售后问题。
- 客户需要课程、认证、安装视频、调试视频和 FAQ。
- 客户询问价格、RFQ、折扣、购买咨询或代理合作。

数据输入：

- 客户问题、产品线、产品型号、区域、应用场景、客户状态、历史订单/工单信号、知识库、产品事实、交付 SOP、运维 FAQ、销售政策边界。

数据流程：

1. `customer-growth-agent` 或 `brand-command-agent` 发送专业问题任务。
2. `ops-delivery-agent` 判断问题类型和所需 skill。
3. 读取 RAG 知识库和 GDP 中的产品、交付、服务、客户赋能数据。
4. 对 R3/R4 输出发送 `risk-governance-agent` 审核。
5. 审核通过后生成回复草稿、工单建议、交付清单或销售跟进建议。

处理过程：

- 方案问题生成方案草稿，但关键产品事实需审核。
- 交付问题生成交付清单和计划草稿，但不得承诺交期。
- 运维问题推荐已审核 FAQ 或工单路径，不做高风险接线/设备参数指导。
- 赋能问题推荐课程、FAQ、积分任务，不承诺认证结果。
- 销售问题只生成销售建议，报价和商业承诺必须真人负责。

输出：

- 专业回复草稿。
- 交付/运维/赋能任务。
- 销售跟进建议。
- 工单建议。
- 审核请求和审计记录。

### 4.7 企业协同校验与经营系统桥接

业务功能：把品牌增长活动连接 PLM、供应链、库存、ERP、财务、法务、客户成功、安全合规等企业系统，但初版只做只读查询、校验和写回建议。

使用场景：

- 推广前检查产品在目标区域是否可售、库存是否支持、是否具备交付能力。
- 订单信号出现后校验 ERP 订单状态、支付、发货、取消、退货。
- 需要判断毛利、预算、投放成本和 ROI。
- 客户反馈、需求、竞品问题需要回流产品/PLM。
- 内容引用客户案例、合同、授权或版权资料前需要法务风险识别。

数据输入：

- Product_Model、Region、Country、Campaign_ID、Order_ID、Customer_ID、RFQ_ID、成本、毛利、库存状态、交付限制、法务风险点。

数据流程：

1. `enterprise-bridge-agent` 接收校验任务。
2. 读取本地 GDP 中已有产品、库存、订单、财务、法务摘要。
3. 如果需要外部系统，生成只读查询任务或人工查询清单。
4. 生成结果建议和写回队列，不直接改外部系统。
5. 关键风险发送给 `risk-governance-agent`。

处理过程：

- 校验产品事实、认证、兼容性、供应和可交付性。
- 识别价格、合同、法务、客户授权、版权风险。
- 生成 PLM 产品反馈和客户成功机会。
- 维护企业协同证据链。

输出：

- 可售性/可交付性校验结果。
- 订单状态校验摘要。
- 毛利/ROI 输入。
- PLM/法务/财务/客户成功写回建议。
- 风险审核请求。

### 4.8 风险分级、Gate、人工审核与硬拦截

业务功能：把所有 AI 输出和工具调用按 R1-R4 风险等级处理，执行 Gate 审核、禁止自动化动作硬拦截、测试发布和事故 CAPA。

使用场景：

- 内容里出现产品参数、认证、兼容性、安装/调试建议。
- 客户要求报价、合同、折扣、退款、赔偿、交期承诺。
- Agent 要调用工具读取客户数据或写回 CRM/ERP。
- 新 skill 或 prompt 准备上线。
- 出现客户投诉、事实错误、越权工具调用或高风险误回复。

数据输入：

- 待审核内容、风险等级、输出对象、数据权限、工具权限、测试结果、运行日志、人工审核意见。

数据流程：

1. 任一 agent 对 R3/R4 输出发送审核请求。
2. `risk-governance-agent` 执行 R1-R4 分类、禁区检查、Gate 校验。
3. 通过/退回/禁止上线结论写入 review、risk_event、audit 表。
4. 事故触发 CAPA 流程，并更新测试集和风险规则候选。

处理过程：

- R1：公开资料、普通课程、已审核链接，可自动处理。
- R2：普通内容、FAQ、邮件草稿、社群回复，可自动或轻审核。
- R3：产品参数、认证、方案建议、交付、运维、销售建议，必须人工审核。
- R4：报价、合同、赔偿、高风险安装/调试、订单/退款修改，禁止 AI 自动处理。
- 高风险动作硬拦截并创建人工处理任务。

输出：

- 审核结论。
- 硬拦截记录。
- Gate 通过/退回/禁止上线记录。
- CAPA 报告草稿。
- 更新测试集、风险规则、MEMORY 候选。

### 4.9 数据底座、本地 GDP、ROI 与经营复盘

业务功能：维护本地 GDP 数据库，把客户、内容、Campaign、订单信号、Agent 运行、风险、ROI、复盘结论和 MEMORY 候选统一管理。

使用场景：

- 每天同步互动、内容推广、邮件、商城、工单和运行日志。
- 每周复盘 Campaign 表现、询盘/RFQ/订单归因。
- 每月计算 AI ROI、售后降本、复购贡献和区域复制建议。
- 从高频问题、审核结论、事故 CAPA 中沉淀长期规则。

数据输入：

- 各 agent 的结构化输出、writeback_plan、review_result、audit_log、运行成本、业务结果、人工复盘结论。

数据流程：

1. 各 agent 输出标准 JSON 或 markdown 结果，并附 `writeback_plan`。
2. `data-roi-memory-agent` 先写入 inbox/staging。
3. `gdp-sync-skill` 校验主键、来源、字段、审核状态、payload_hash。
4. 合格数据 upsert 到本地 GDP。
5. ROI 和复盘结果生成 MEMORY 候选，审核后写入各 agent 的 `MEMORY.md`。

处理过程：

- 去重、主键校验、来源追踪、审核状态管理。
- 计算 Campaign 贡献、AI 成本、人工节省、售后降本、复购收益。
- 建立 Customer/Product/Campaign/Order/Agent/ROI/Risk 360 的本地可查询视图。

输出：

- 本地 GDP 表记录。
- ROI 报表。
- 经营复盘摘要。
- MEMORY 候选。
- 跨 agent 改进任务。

## 5. 适合做成 OpenClaw skill 的动作

skill 应该封装稳定、可复用、可审核的业务动作。不要把整条业务链塞进一个 skill；跨 agent 协作交给 `session send` 和 cron 调度。

| skill 名称 | 所属 agent | 适用动作 | 输入 | 处理 | 输出 |
|---|---|---|---|---|---|
| `campaign-plan-skill` | `brand-command-agent` | 区域/产品/Campaign 计划 | 目标、区域、产品线、平台、ROI 目标 | 生成任务、Owner、SLA、风险等级 | Campaign 计划、任务清单 |
| `task-dispatch-skill` | `brand-command-agent` | 拆解并派发跨 agent 任务 | 需求、优先级、依赖 | 生成 session send payload | 分发消息、任务记录 |
| `quality-acceptance-skill` | `brand-command-agent` | 任务验收 | 交付物、验收标准、审核结果 | 检查业务/质量/数据/风险/系统/复用 | 验收结论 |
| `content-asset-draft-skill` | `content-campaign-agent` | 文章、社媒、视频、邮件草稿 | Campaign、产品、场景、语言 | 生成草稿并附事实来源 | 内容草稿、审核状态 |
| `channel-localize-skill` | `content-campaign-agent` | 区域平台适配 | 平台、国家、语言、内容草稿 | 改写标题、标签、CTA、格式 | 平台版本 |
| `content-performance-ingest-skill` | `content-campaign-agent` | 推广结果采集 | UTM、平台数据、互动、询盘 | 标准化采集字段 | 内容表现记录 |
| `social-inbox-normalize-skill` | `customer-growth-agent` | 统一互动收件箱 | 原始互动、邮件、表单、商城事件 | 标准化 Interaction 字段 | interaction 记录 |
| `lead-intent-risk-route-skill` | `customer-growth-agent` | 意图识别与分流 | Message_Content、客户信息 | 判断 intent、risk、assigned_ai | 分流单、回复草稿 |
| `email-trigger-plan-skill` | `customer-growth-agent` | 事件触发邮件 | 客户事件、触达许可、邮件规则 | 检查退订和频率，生成邮件草稿 | 邮件动作建议 |
| `customer-lifecycle-score-skill` | `customer-growth-agent` | 客户状态与评分 | 互动、订单、课程、工单、复购 | 更新状态机和评分 | 状态更新建议 |
| `ops-router-skill` | `ops-delivery-agent` | 专业问题路由 | 客户问题、intent、risk | 选择方案/交付/运维/赋能/销售路径 | 专业任务 |
| `solution-draft-skill` | `ops-delivery-agent` | 产品方案草稿 | 产品线、型号、场景、客户需求 | 生成方案草稿并标注事实审核点 | 方案草稿 |
| `delivery-checklist-skill` | `ops-delivery-agent` | 交付计划和现场条件 | 项目需求、区域、产品 | 生成交付清单，不承诺交期 | 交付任务草稿 |
| `service-faq-ticket-skill` | `ops-delivery-agent` | 运维/售后/错误码处理 | 故障、错误码、客户状态 | 推荐已审核 FAQ 或工单路径 | 工单建议 |
| `enablement-path-skill` | `ops-delivery-agent` | 课程/认证/安装调试视频推荐 | 客户阶段、产品、学习目标 | 推荐课程路径和资料 | 赋能建议 |
| `sales-followup-suggestion-skill` | `ops-delivery-agent` | 销售跟进建议 | RFQ、购买咨询、客户评分 | 生成跟进建议，不报价 | 销售建议 |
| `availability-check-skill` | `enterprise-bridge-agent` | 库存/供应/可交付性校验 | 产品型号、区域、国家 | 查询或生成只读核验清单 | 可售性建议 |
| `erp-order-signal-check-skill` | `enterprise-bridge-agent` | ERP 订单信号校验 | Order_ID、客户、Campaign | 校验状态，不修改订单 | 订单状态摘要 |
| `plm-feedback-skill` | `enterprise-bridge-agent` | 产品反馈回流 | 客户反馈、竞品、需求 | 生成 PLM 反馈建议 | PLM 写回队列 |
| `finance-roi-input-skill` | `enterprise-bridge-agent` | 毛利/成本/ROI 输入 | 成本、毛利、投放费用 | 形成 ROI 计算输入 | ROI 输入记录 |
| `risk-gate-review-skill` | `risk-governance-agent` | R1-R4 和 Gate 审核 | 待审核输出、工具调用、数据权限 | 分类、拦截、通过/退回 | 审核结论 |
| `forbidden-action-block-skill` | `risk-governance-agent` | 禁止自动化检查 | 动作、对象、上下文 | 匹配禁区清单 | 硬拦截记录 |
| `agent-test-pack-skill` | `risk-governance-agent` | 测试集和上线门槛 | Agent/skill 版本、测试样例 | 生成/检查测试包 | 测试报告 |
| `audit-capa-skill` | `risk-governance-agent` | 事故响应和 CAPA | 告警、日志、投诉、错误 | 暂停、根因、修复、回归 | CAPA 报告 |
| `gdp-ingest-normalize-skill` | `data-roi-memory-agent` | 原始数据入站 | 各 agent 输出、外部导出 | 标准化、补元数据、计算 hash | inbox 记录 |
| `gdp-sync-skill` | `data-roi-memory-agent` | GDP upsert | inbox 记录 | 校验主键、来源、审核状态 | GDP 表更新 |
| `roi-attribution-skill` | `data-roi-memory-agent` | ROI 归因 | Campaign、内容、询盘、订单、成本 | 计算 ROI 和贡献 | ROI 报表 |
| `memory-candidate-review-skill` | `data-roi-memory-agent` | MEMORY 候选生成 | FAQ、审核、事故、复盘结论 | 生成候选规则，等待审核 | MEMORY 候选 |

## 6. 适合做成 OpenClaw cron 定时任务的动作

cron 只负责定时触发和短指令，不承载长业务规则。稳定参数、字段定义、审核规则和处理流程应放在 skill、MEMORY.md、GDP schema 或配置文件中。

| cron 名称 | 频率建议 | 触发 agent | 任务 |
|---|---|---|---|
| `daily-gdp-ingest-sync` | 每天 08:00 | `data-roi-memory-agent` | 收集各 agent 前一日 inbox/outbox、运行日志、审核记录，执行 GDP 标准化和同步 |
| `daily-social-inbox-routing` | 每天 09:00、14:00、18:00 | `customer-growth-agent` | 扫描新互动、识别意图/风险、生成分流任务和人工处理队列 |
| `daily-campaign-performance-ingest` | 每天 17:30 | `content-campaign-agent` | 采集内容推广数据、UTM、询盘、RFQ、订单信号 |
| `daily-risk-review-queue` | 每天 18:00 | `risk-governance-agent` | 汇总 R3/R4 待审核、硬拦截、越权工具调用和投诉风险 |
| `weekly-campaign-planning` | 每周一 09:30 | `brand-command-agent` | 生成本周区域/产品/Campaign 任务计划和跨 agent 派发消息 |
| `weekly-content-calendar-review` | 每周一 11:00 | `content-campaign-agent` | 生成全球内容日历、A/B 测试变量和本地化待办 |
| `weekly-ops-sla-review` | 每周三 16:00 | `ops-delivery-agent` | 复查方案、交付、运维、赋能、销售建议队列的 SLA 和阻塞 |
| `weekly-enterprise-bridge-check` | 每周四 15:00 | `enterprise-bridge-agent` | 检查产品可售、库存、订单、毛利、法务反馈队列 |
| `weekly-roi-review` | 每周五 16:30 | `data-roi-memory-agent` | 生成 Campaign、内容、Agent 成本与收益周报 |
| `monthly-agentops-gate-review` | 每月第 1 个工作日 10:00 | `risk-governance-agent` | 检查 Agent/skill 测试包、上线审批、回归测试和退役候选 |
| `monthly-business-digital-twin-review` | 每月第 3 个工作日 14:00 | `data-roi-memory-agent` | 生成 Customer/Product/Campaign/Order/Agent/ROI/Risk 360 复盘 |
| `monthly-memory-consolidation` | 每月第 5 个工作日 15:00 | `data-roi-memory-agent` | 汇总 MEMORY 候选，等待人工审核后写入各 agent 的 MEMORY.md |

## 7. session send 协作协议

跨 agent 消息必须结构化，避免自然语言长消息造成职责混乱。

```json
{
  "from_agent": "customer-growth-agent",
  "to_agent": "ops-delivery-agent",
  "intent": "route_professional_question",
  "entity_type": "interaction",
  "entity_id": "INT-20260529-0001",
  "customer_id": "CUS-0001",
  "risk_level": "R3",
  "required_skill": "solution-draft-skill",
  "inputs": {
    "product_line": "PL1",
    "product_model": "MODEL-001",
    "question": "客户询问认证、兼容性和方案配置"
  },
  "expected_output": "方案草稿、事实审核点、下一步动作",
  "writeback_plan": {
    "target_table": "gdp_ops_cases",
    "operation": "upsert",
    "review_required": true
  },
  "human_required": true
}
```

常见协作链路：

- `brand-command-agent` -> `content-campaign-agent`：生成 Campaign 内容计划。
- `content-campaign-agent` -> `risk-governance-agent`：审核内容事实、版权、品牌语气和区域合规。
- `customer-growth-agent` -> `ops-delivery-agent`：转交方案、交付、运维、赋能、销售问题。
- `ops-delivery-agent` -> `enterprise-bridge-agent`：校验库存、可交付性、ERP 订单、毛利和法务风险。
- 任一 agent -> `risk-governance-agent`：R3/R4 审核、禁区拦截、工具权限评估。
- 任一 agent -> `data-roi-memory-agent`：提交 GDP 写回、运行证据、复盘结论和 MEMORY 候选。

## 8. 需要沉淀到 MEMORY.md 的长期规则

MEMORY.md 只沉淀稳定长期规则、已确认事实、审核口径和复盘结论。临时任务、一次性数据、未经审核的猜测不进入 MEMORY.md。

### 8.1 全局经营与 AI 边界

- L5 的边界是：AI 负责识别、生成、推荐、分流、低风险执行和复盘；真人负责战略、报价、合同、交付承诺、高风险技术判断、法务责任和例外处理。
- OpenClaw 初版不是平台 UI，而是 agent 工作流包。
- 88 个原始 Agent 是能力图谱；OpenClaw 落地应合并为少量独立 agent 工作区。
- 每个 agent 独立拥有 skill、cron、memory、工作目录；跨 agent 使用 `session send`。

### 8.2 风险等级与审核规则

- R1：公开资料、普通课程、已审核链接，可自动处理。
- R2：普通内容、FAQ、邮件草稿、社群回复，可自动或轻审核。
- R3：产品参数、认证、方案建议、交付、运维、销售建议，必须人工审核。
- R4：报价、合同、赔偿、高风险安装/调试、订单/退款修改，禁止 AI 自动处理。
- 高风险拦截率必须 100%。
- 产品事实错误、越权工具调用、敏感信息泄露、严重 Prompt Injection 绕过必须为 0。
- 回归测试通过率目标不低于 97%，审计日志完整率必须 100%。

### 8.3 禁止自动化动作

- 禁止自动报价。
- 禁止自动承诺交期。
- 禁止自动承诺折扣、返点、付款条件。
- 禁止自动修改订单、价格、库存。
- 禁止自动退款、取消订单。
- 禁止自动删除负面评论。
- 禁止自动导出客户清单。
- 禁止绕过退订名单。
- 禁止自动修改 CRM 关键字段。
- 禁止自动指导高风险安装、接线、设备参数修改。
- 禁止自动确认故障原因。
- 禁止自动处理投诉、赔偿、合同、法务风险。
- 禁止自动发送合同或付款信息。
- 禁止创建未经审批的商业承诺。

### 8.4 客户与邮件规则

- 客户状态机从 Unknown Visitor 到 Advocate / Referrer，状态变更必须有事件依据。
- RFQ 确认邮件可生成，但禁止自动报价。
- 退订必须自动执行退订确认，并进入抑制名单。
- 投诉必须人工处理。
- 加购未购买可提醒，但必须控制触达频率。
- 安装/调试相关内容只能推荐已审核资料，高风险问题必须转人工。

### 8.5 内容与产品事实规则

- 内容草稿必须带 Content_ID、Campaign_ID、版本、来源、适用区域、语言、风险等级和审核状态。
- 涉及参数、型号、认证、兼容性、BOM、安装调试、错误码的内容必须引用产品事实来源，并进入 R3 审核。
- 区域本地化必须检查平台规则、语言、文化禁忌、广告限制、邮件许可和透明披露。
- 高表现内容可以复用，但复用前要检查版权、客户授权、Logo、人物、音乐、字体和竞品素材风险。

### 8.6 数据、写回与审计规则

- 本地 GDP 是工作流包的业务数据源，不是外部平台的替代品。
- 所有写回必须包含主键、来源、payload_hash、review_status、audit_log_id。
- 外部系统写回先进入 `gdp_writeback_queue`，普通 agent 不直接写 CRM/ERP/PLM/财务/法务。
- CRM 关键字段默认只生成写入建议。
- 数据同步不得为缺失主键的业务记录自动编造主键；缺主键记录进入异常队列。
- 任一输出如需长期沉淀，先进入 `gdp_memory_candidates`，人工审核后写入 MEMORY.md。

### 8.7 复盘结论沉淀规则

- 可沉淀：稳定有效的客户分流规则、区域平台规则、邮件触发规则、FAQ、产品事实修正、风险拦截规则、Prompt 改进、内容复用规律、ROI 归因结论。
- 不沉淀：单次任务结论、未经审核事实、过期平台规则、无证据的经验判断、客户隐私明文。
- 复盘结论必须记录来源事件、证据、适用范围、审核人、有效期或复查周期。

## 9. 本地 GDP 数据库设计

建议使用本地 SQLite：`data/gdp.sqlite`。各 agent 可有自己的 `data/inbox/` 和 `data/outbox/`，但 GDP 写入由 `data-roi-memory-agent` 统一执行。原始导入先进入 `data/inbox/*.jsonl`，通过 `gdp-ingest-normalize-skill` 和 `gdp-sync-skill` 入库。

统一字段约定：

- `review_status` 枚举：`draft`、`pending_review`、`approved`、`rejected`、`blocked`、`synced`、`failed`、`needs_human`。
- `risk_level` 枚举：`R1`、`R2`、`R3`、`R4`。
- 所有业务表都应有：`source_system`、`source_ref`、`payload_hash`、`audit_log_id`、`created_at`、`updated_at`。

| 表名 | 主键 | 关键字段 | 数据来源 | 写回规则 | 审核状态 |
|---|---|---|---|---|---|
| `gdp_source_inbox` | `inbox_id` | `source_system`, `source_type`, `source_ref`, `raw_path`, `payload_hash`, `normalized_status`, `error_message` | 各 agent outbox、外部导出、人工导入 | 只追加；同步成功后标记 `synced` | `draft/synced/failed` |
| `gdp_agents` | `agent_id` | `agent_name`, `workspace`, `owner`, `risk_owner`, `allowed_skills`, `data_scope`, `status`, `version` | Agent 注册表、OpenClaw 工作区 | 由 AgentOps 审核后更新 | `pending_review/approved/blocked` |
| `gdp_skills` | `skill_id` | `agent_id`, `skill_name`, `purpose`, `input_schema`, `output_schema`, `risk_level`, `version` | skill 清单 | 新增/变更需 Gate 审核 | `pending_review/approved/rejected` |
| `gdp_cron_jobs` | `cron_id` | `agent_id`, `job_name`, `schedule`, `prompt`, `skill_refs`, `enabled`, `last_run_at` | cron 配置 | 更新后记录版本和审批人 | `pending_review/approved/blocked` |
| `gdp_campaigns` | `campaign_id` | `region`, `country`, `platform`, `product_line`, `scenario`, `goal`, `roi_target`, `owner`, `status` | 战役计划、内容推广任务 | 可写本地；外部营销系统写回进队列 | `draft/pending_review/approved/synced` |
| `gdp_content_assets` | `content_id` | `campaign_id`, `asset_type`, `title`, `language`, `platform`, `product_model`, `cta`, `evidence_status`, `publish_status` | 内容生成、内容日历、人工上传 | 发布前必须通过内容/风险审核 | `draft/pending_review/approved/rejected/published` |
| `gdp_content_performance` | `performance_id` | `content_id`, `utm_source`, `utm_medium`, `utm_campaign`, `impressions`, `clicks`, `inquiries`, `rfqs`, `orders` | 平台采集、UTM、BI | 只追加或按日期 upsert | `synced/failed` |
| `gdp_channel_rules` | `rule_id` | `region`, `country`, `platform`, `language`, `rule_type`, `rule_text`, `effective_from`, `expires_at` | 区域平台库、复盘结论、人工维护 | 规则变更需区域 Owner 审核 | `pending_review/approved/rejected` |
| `gdp_customers` | `customer_id` | `crm_id`, `cdp_id`, `email_hash`, `country`, `language`, `lifecycle_state`, `lead_score`, `owner` | CRM/CDP 摘要、Social Inbox、商城、邮件 | CRM 关键字段只写建议队列 | `draft/pending_review/approved/synced` |
| `gdp_customer_identity_map` | `identity_id` | `customer_id`, `identity_type`, `identity_value_hash`, `platform`, `confidence`, `matched_by` | 客户身份匹配 | 高置信才可建议写回 CRM/CDP | `pending_review/approved/rejected` |
| `gdp_interactions` | `interaction_id` | `source_platform`, `customer_id`, `social_id`, `email_hash`, `country`, `language`, `product_line`, `interaction_type`, `message_content_ref`, `intent_type`, `risk_level`, `assigned_agent`, `assigned_human`, `next_action`, `crm_sync_status` | Social Inbox、邮件、表单、商城、工单 | 只写本地；CRM 同步进队列 | `draft/pending_review/approved/synced/blocked` |
| `gdp_email_events` | `email_event_id` | `customer_id`, `trigger_event`, `template_id`, `permission_status`, `suppression_status`, `send_recommendation`, `frequency_check` | 邮件营销、客户事件 | 退订自动写抑制；发送建议需合规检查 | `pending_review/approved/blocked/synced` |
| `gdp_products` | `product_model` | `product_line`, `spec_version`, `certifications`, `compatibility`, `bom_ref`, `fact_owner`, `fact_source` | PLM 摘要、产品事实库、人工维护 | 产品事实变更需产品 Owner 审核 | `pending_review/approved/rejected` |
| `gdp_availability` | `availability_id` | `product_model`, `region`, `country`, `inventory_status`, `deliverability_status`, `as_of_date`, `source_system` | 库存、供应链、交付规则 | 不直接改库存；只生成建议 | `synced/failed/needs_human` |
| `gdp_rfq_order_signals` | `signal_id` | `customer_id`, `campaign_id`, `interaction_id`, `signal_type`, `rfq_status`, `order_id`, `order_status`, `estimated_value` | 内容采集、商城、ERP 摘要、CRM | 订单/报价相关写回必须人工 | `pending_review/approved/blocked/synced` |
| `gdp_ops_cases` | `case_id` | `customer_id`, `case_type`, `product_model`, `risk_level`, `assigned_agent`, `assigned_human`, `sla`, `status`, `output_ref` | 客户分流、AI 运营作战部 | R3/R4 输出审核后才能对外 | `draft/pending_review/approved/rejected/needs_human` |
| `gdp_tasks` | `task_id` | `task_name`, `source_entity_type`, `source_entity_id`, `business_goal`, `owner`, `agent_id`, `skill_id`, `risk_level`, `sla`, `acceptance_criteria`, `status` | 任务调度、cron、人工创建 | 任务状态本地更新；外部同步进队列 | `draft/pending_review/approved/synced` |
| `gdp_reviews` | `review_id` | `entity_type`, `entity_id`, `gate`, `reviewer`, `risk_level`, `conclusion`, `evidence_ref`, `reviewed_at` | 风险审核、Gate、人工审批 | 只追加；作为审计证据 | `approved/rejected/blocked/needs_human` |
| `gdp_risk_events` | `risk_event_id` | `entity_type`, `entity_id`, `risk_level`, `rule_id`, `blocked_action`, `human_owner`, `status` | 禁区拦截、投诉、越权、红队测试 | 高风险事件不得覆盖删除 | `blocked/needs_human/approved/closed` |
| `gdp_agent_runs` | `run_id` | `agent_id`, `skill_id`, `session_id`, `input_hash`, `output_ref`, `tool_call_summary`, `status`, `cost`, `latency_ms` | OpenClaw 运行日志、agent outbox | 只追加，支持审计和 ROI | `synced/failed` |
| `gdp_capa` | `capa_id` | `risk_event_id`, `severity`, `root_cause`, `fix_action`, `regression_test_ref`, `owner`, `due_date`, `closed_at` | 事故响应、投诉、审计 | CAPA 关闭需审核 | `pending_review/approved/closed` |
| `gdp_roi_metrics` | `roi_id` | `month`, `campaign_id`, `agent_id`, `region`, `product_line`, `incremental_margin`, `labor_savings`, `service_cost_reduction`, `repeat_purchase_gain`, `ai_cost`, `roi` | Campaign、订单信号、成本、BI、人工复盘 | 月度锁定后只追加修正记录 | `draft/pending_review/approved` |
| `gdp_knowledge_items` | `knowledge_id` | `domain`, `title`, `content_hash`, `source_entity_type`, `source_entity_id`, `version`, `effective_status` | FAQ、SOP、产品事实、交付/运维资料 | 更新知识库需 Owner 审核 | `pending_review/approved/rejected` |
| `gdp_memory_candidates` | `candidate_id` | `agent_id`, `category`, `proposed_rule`, `evidence_ref`, `scope`, `reviewer`, `memory_target`, `decision` | 复盘、审核、事故、FAQ、Prompt 优化 | 人工批准后写入 MEMORY.md | `pending_review/approved/rejected` |
| `gdp_writeback_queue` | `writeback_id` | `target_system`, `target_entity`, `operation`, `payload_ref`, `requires_human`, `approval_id`, `sync_status`, `error_message` | 各 agent writeback_plan | 外部系统写回唯一出口 | `pending_review/approved/synced/failed/blocked` |
| `gdp_audit_logs` | `audit_log_id` | `actor_type`, `actor_id`, `action`, `entity_type`, `entity_id`, `input_ref`, `output_ref`, `session_id`, `timestamp` | 所有 agent、skill、cron、审核动作 | 只追加，不允许业务 agent 修改 | `synced` |

## 10. GDP 写回规则

1. 所有 agent 只能直接写自己的 outbox，不直接写核心 GDP 表。
2. `data-roi-memory-agent` 是 GDP 写入 Owner。
3. 入库前必须检查主键、来源、payload_hash、字段完整性、风险等级、审核状态。
4. R1/R2 本地记录可自动入库；R3/R4 必须带审核结论。
5. 外部系统写回统一进入 `gdp_writeback_queue`。
6. CRM 关键字段、ERP 订单、价格、库存、合同、财务、法务相关写回默认 `requires_human=true`。
7. 禁止对审计日志、风险事件、CAPA 记录做覆盖式修改；只能追加修正记录。
8. 数据质量失败进入 `failed` 或 `needs_human`，不得静默丢弃。
9. MEMORY 写入必须从 `gdp_memory_candidates` 审核通过后执行。

## 11. 初版交付清单

后续真正实现工作流包时，应交付：

- 7 个 OpenClaw agent 工作区。
- 每个工作区的 `AGENTS.md`、`MEMORY.md`、`skills/`、`cron/`、`data/inbox/`、`data/outbox/`。
- skill 清单和每个 skill 的 `SKILL.md`。
- OpenClaw cron 定时任务配置。
- 本地 GDP：`data/gdp.sqlite`、schema、初始化脚本、同步脚本。
- `references/`：风险等级、禁区清单、客户状态机、字段字典、session send 协议、写回协议、Gate 规则。
- `project.md`：当前包的 agent、skill、cron、GDP、运行方式总览。
- `validation`：结构校验脚本，至少校验每个 agent 是否有 skill/cron/memory/workdir，GDP schema 是否覆盖主键/来源/审核状态/写回规则。

## 12. 验收标准

- 能清楚证明不是 UI 平台方案，而是 OpenClaw agent 工作流包。
- 不超过 7 个初版 agent，且每个 agent 职责边界明确。
- 每个业务功能都有使用场景、数据输入、数据流程、处理过程和输出。
- skills 覆盖内容、客户、运营作战、企业协同、风险治理、GDP/ROI/Memory。
- cron 只做定时触发和短任务，不承载长规则。
- MEMORY.md 只沉淀长期规则、业务口径、审核规则和复盘结论。
- 本地 GDP 明确表、字段、主键、来源、写回规则和审核状态。
- R3/R4 与禁区动作有硬拦截和人工审核路径。
- 所有跨 agent 协作有 `session send` 协议。
- 静态文件完成不等于真实运行完成；上线前还需要在真实 OpenClaw 环境中导入 cron、运行样例、验证 session send、验证 GDP 写回和审核链路。

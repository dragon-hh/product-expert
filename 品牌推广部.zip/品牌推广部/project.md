# 品牌推广部 MVP-1 项目说明

## 项目定位

MVP-1 是品牌发展部 AI 作战团队的低风险前端增长包：输入企业增长目标，输出 Campaign brief、可行性校验、内容资产草稿、平台推广包、UTM/Content_ID、人工审核清单和 GDP 记录。

## 资产统计

- Agent 工作区：4 个
- Core skill：21 个
- Cron：5 个
- 本地 GDP 表：12 张
- 公共 reference：11 个

## 最小运行路径

1. `growth-campaign-planner-agent` 接收增长目标并生成 Campaign brief。
2. 通过 `session send` 请求 `growth-data-feasibility-agent` 做产品/供应链/客户/ROI 校验。
3. 可行性通过后请求 `content-asset-agent` 生成内容资产草稿和审核清单。
4. 请求 `channel-promotion-pack-agent` 输出平台发布包、内容日历、UTM 和发布前检查表。
5. 规划 Agent 汇总 Campaign 发布包，所有结果写入本地 GDP 并保持待人工审核状态。

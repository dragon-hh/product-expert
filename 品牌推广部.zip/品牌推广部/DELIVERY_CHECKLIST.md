# MVP-1 交付清单

## Agent 工作区

- [x] `growth-campaign-planner-agent`：`workspace-growth-campaign-planner/`、5 个 skill、`cron/`、`data/inbox/`、`data/outbox/`。
- [x] `growth-data-feasibility-agent`：`workspace-growth-data-feasibility/`、5 个 skill、`cron/`、`data/inbox/`、`data/outbox/`。
- [x] `content-asset-agent`：`workspace-content-asset/`、6 个 skill、`cron/`、`data/inbox/`、`data/outbox/`。
- [x] `channel-promotion-pack-agent`：`workspace-channel-promotion-pack/`、5 个 skill、`cron/`、`data/inbox/`、`data/outbox/`。

## Core skills

- [x] 规划 Agent：5 个。
- [x] 可行性 Agent：5 个。
- [x] 内容 Agent：6 个。
- [x] 渠道 Agent：5 个。

## Cron

- [x] `weekly-campaign-planning`
- [x] `weekly-feasibility-refresh`
- [x] `weekly-content-generation`
- [x] `weekly-promotion-pack`
- [x] `friday-mvp1-review`

## 本地 GDP

- [x] `mvp1_campaigns`：Campaign brief and planning status.
- [x] `mvp1_platform_channels`：Approved platform channel library.
- [x] `mvp1_products`：Product facts, certifications, compatibility, and available regions.
- [x] `mvp1_feasibility_checks`：Inventory, supply, deliverability, customer-profile, and ROI feasibility checks.
- [x] `mvp1_customer_profiles`：Customer profile and segmentation summaries without exporting customer details.
- [x] `mvp1_roi_estimates`：Budget, margin, lead, RFQ, order, and ROI estimates.
- [x] `mvp1_content_requirements`：Content asset requirements by campaign, platform, language, scenario, and CTA.
- [x] `mvp1_content_assets`：Generated draft content assets with fact references and review status.
- [x] `mvp1_promotion_packs`：Human-reviewable platform promotion packs.
- [x] `mvp1_utm_links`：UTM, Content_ID, Campaign_ID mapping.
- [x] `mvp1_reviews`：Append-only human and skill review records.
- [x] `mvp1_agent_runs`：OpenClaw agent and skill execution logs.

## 协议与模板

- [x] `references/session-send-protocol.md`
- [x] `references/campaign-brief-template.md`
- [x] `references/content-requirement-template.md`
- [x] `references/content-asset-package-template.md`
- [x] `references/platform-promotion-pack-template.md`
- [x] `references/human-review-checklist.md`
- [x] `MVP1_ACCEPTANCE_SAMPLE.md`

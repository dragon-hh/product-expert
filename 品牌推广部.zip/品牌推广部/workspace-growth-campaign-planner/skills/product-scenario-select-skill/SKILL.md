---
name: product-scenario-select-skill
description: "选择产品线、型号和应用场景。"
---

# product-scenario-select-skill

## Purpose

选择产品线、型号和应用场景。

## Owner

- Agent：增长战役规划 Agent（`growth-campaign-planner-agent`）
- Workspace：`workspace-growth-campaign-planner`

## Inputs

- 用户请求、cron payload 或上游 `session send` 任务。
- `campaign_id`、增长目标、区域/国家、产品线/型号、平台、预算、周期、目标线索/RFQ。
- 本地 GDP：`mvp1_campaigns`, `mvp1_platform_channels`, `mvp1_products`, `mvp1_content_requirements`, `mvp1_agent_runs`, `mvp1_reviews`。
- 公共规则：`references/mvp1-scope-rules.md`、`references/local-gdp-schema.md`、`references/output-templates.md`。

## Procedure

1. 读取 `data/catalog.json`，确认本 skill 可使用的 GDP 表和主键。
2. 读取 `data/inbox/*.jsonl` 或上游 payload 中的 `input_refs`。
3. 校验 `campaign_id`、来源证据、审核状态和风险等级。
4. 执行本 skill 的业务动作：选择产品线、型号和应用场景。
5. 标注事实来源、适用区域/平台/语言、产品型号、版本和数据缺口。
6. 对产品事实、认证、兼容性、安装调试、ROI、客户画像或对外发布内容标记 `review_required=true`。
- 如需下游协作，按 `references/session-send-protocol.md` 生成 `session send` payload。
7. 只输出草稿、建议、发布包或写回计划，不自动发布、不自动发送、不写 CRM/ERP。

## Outputs

必须同时输出：

```json
{
  "campaign_id": "CMP-YYYY-REGION-PRODUCT-NNN",
  "skill_id": "product-scenario-select-skill",
  "owner_agent": "growth-campaign-planner-agent",
  "status": "draft|pending_review|approved|blocked",
  "risk_level": "R2",
  "review_required": true,
  "source_refs": [],
  "result": {},
  "writeback_plan": [],
  "next_agent_message": null
}
```

## Error Handling

- 缺少产品事实、库存、可交付性、客户画像或预算时，返回 `insufficient_data` 并列出缺口。
- 发现自动发布、自动发送、CRM/ERP 写回诉求时，返回 `scope_blocked`。
- 发现人工锁定字段时，不覆盖原值，只追加待审核建议。
